#Cancer Hallmark Wilcoxon Test
#Determining which cancer hallmark gene sets are significantly under or over expressed by producing plots 

#loading data and obtaining the gene enrichment scores for 56 and 100 day data for cancer hallmark gene sets 
temp=read.csv(file="56 day results/mouse2human_rlogwtmutant.csv")
rlog_wtmutant=as.matrix(temp[,2:9])
rownames(rlog_wtmutant)=temp[,1]

library(GSVA)
library(GSEABase)
#Cancer hallmark pathway analysis 
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")

gsvaEnrichmentScore_56_day<-gsva(rlog_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)



temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant.csv")
normalized_wtmutant=as.matrix(temp[,2:11])
rownames(normalized_wtmutant)=temp[,1]

gsvaEnrichmentScore_100_day<-gsva(normalized_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)




#wilcoxon test function normal method to determine if significantly differentally expressed 
gene_age_wilcoxon_test_normal=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]])$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_normal"
  return(gene_age_wilcoxon_test)
}

#wilcoxon test function to determine if significantly underexpressed in mutant compared to wildtype
gene_age_wilcoxon_test_less=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]],alternative ="less")$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_less"
  return(gene_age_wilcoxon_test)
}
#wilcoxon test function to determine if signigicantly overexpressed in mutant compared to wildtype  
gene_age_wilcoxon_test_greater=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]],alternative ="greater")$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_greater"
  return(gene_age_wilcoxon_test)
}


#determining the %unicellular genes in each cancer hallmark gene set 
Phylostrata=read.csv(file="Phylostrata.csv")
GOslim_set=msigDB50
phylostrata_goslim=matrix(0,nrow=length(GOslim_set),ncol=1)
rownames(phylostrata_goslim)=names(GOslim_set)
for (i in 1:length(GOslim_set))
{
  uc=0
  mc=0
  for (j in 1:length(GOslim_set[[names(GOslim_set)[i]]]@geneIds))
  {
    if (sum(GOslim_set[[names(GOslim_set[i])]]@geneIds[j]==Phylostrata[,1])==1)
    {
      if (Phylostrata[GOslim_set[[names(GOslim_set)[i]]]@geneIds[j]==Phylostrata[,1],3]<4)
      {
        uc=uc+1
      }
      else
      {
        mc=mc+1
      }
    }
  }
  if ((uc+mc)>0)
  {
    phylostrata_goslim[i]=uc/(uc+mc)
  }
  else
  {
    phylostrata_goslim[i]=-1
  }
}


colnames( phylostrata_goslim)='uc/(uc+mc)'
goslim_wilcoxon_test_normal=gene_age_wilcoxon_test_normal(gsvaEnrichmentScore_56_day)
goslim_wilcoxon_test_greater=gene_age_wilcoxon_test_greater(gsvaEnrichmentScore_56_day)
goslim_wilcoxon_test_less=gene_age_wilcoxon_test_less(gsvaEnrichmentScore_56_day)
cancer_wilcoxon_test_full_56_day=cbind(goslim_wilcoxon_test_normal,goslim_wilcoxon_test_greater,goslim_wilcoxon_test_less,phylostrata_goslim)


colnames( phylostrata_goslim)='uc/(uc+mc)'
goslim_wilcoxon_test_normal=gene_age_wilcoxon_test_normal(gsvaEnrichmentScore_100_day)
goslim_wilcoxon_test_greater=gene_age_wilcoxon_test_greater(gsvaEnrichmentScore_100_day)
goslim_wilcoxon_test_less=gene_age_wilcoxon_test_less(gsvaEnrichmentScore_100_day)
cancer_wilcoxon_test_full_100_day=cbind(goslim_wilcoxon_test_normal,goslim_wilcoxon_test_greater,goslim_wilcoxon_test_less,phylostrata_goslim)


test=cbind(rownames(cancer_wilcoxon_test_full_56_day),cancer_wilcoxon_test_full_56_day[,2:3],cancer_wilcoxon_test_full_100_day[,2:4])
colnames(test)=c('Cancer','56 greater','56 less','100 greater','100 less','Uni/Multi cellular')
#classifying multicellular, unicellular or neither processes for each gene set 

for (i in 1:dim(test)[1])
{
  if (test[i,6]>0.7)
  {
    test[i,6]='u'
  }
  else if (test[i,6]<0.3)
  {
    test[i,6]='m'
  }
  else 
  {
    test[i,6]='n'
  }
}

#Ranking of processes based on wilcoxon test p values 
rank_processes=matrix(0,ncol=50,nrow=4)
for (i in 1:50)
{
  a=match(i,order(full_pvalues[,2]))
  b=match(i,order(full_pvalues[,3]))
  c=match(i,order(full_pvalues[,4]))
  d=match(i,order(full_pvalues[,5]))
  rank_processes[,i]=c(a,b,c,d)
}
colnames(rank_processes)=full_pvalues[,1]
rownames(rank_processes)=c("rank56greater","rank56less","rank100greater","rank100less")
rank_processes=cbind(rank_processes[1,]-rank_processes[3,],rank_processes[2,]-rank_processes[4,])
rank_processes=(rank_processes^2)^0.5
#defining significant processes as ones that have changed rank by 20 or more between 56 and 100 day 
sig56v100=rownames(rank_processes[((rank_processes[,1]>19)+(rank_processes[,2]>19))>0,])
#graphs 
full_pvalues=test


full_pvalues_log=matrix(as.numeric(full_pvalues[,2:5]),nrow=50,ncol=4)
rownames(full_pvalues_log)=full_pvalues[,1]
full_pvalues_log=-log10(full_pvalues_log)

#obtaining the log p values for significant processes. 
full_pvalues_log_sig=c()
for (i in 1:length(sig56v100))
{
  full_pvalues_log_sig=rbind(full_pvalues_log_sig,full_pvalues_log[rownames(full_pvalues_log)==sig56v100[i],])
}

#storing the pvalues for multicellular and unicellular processes. 
mpvalues=c()
upvalues=c()
for (i in 1:50)
{
  full_pvalues[i,1]=paste(strsplit(full_pvalues[i,1],split="")[[1]][-c(1:9)],collapse ="")
  if (full_pvalues[i,6]=='m')
  {
    mpvalues=rbind(mpvalues,full_pvalues_log[i,])
  }
  else if (full_pvalues[i,6]=='u')
  {
    upvalues=rbind(upvalues,full_pvalues_log[i,])
  }
}

#generating plots

plot(full_pvalues_log[,1],full_pvalues_log[,3],xlab="56 day",ylab="100 day",main="-log P values for Mutant vs Wildtype in Processes Overexpressed",xlim=c(0, 3.1),ylim=c(0,2.5))
#labelling multicellular processes green and unicellular processes blue
points(mpvalues[,1],mpvalues[,3],col="green")
points(upvalues[,1],upvalues[,3],col="blue")
#there is a group of gene sets clustered together and need to seperate that out 
legend(x=2.3,y=2.2,legend=rownames(clustered_together),title='Clustered',cex=0.7)
#removing locations which have two gene sets in the same location which will produce overlapping labels. Place labels afterwards 
full_pvalues_log_temp=full_pvalues_log[-c(6,17,20,22,21,40),]
full_pvalues_log_temp=full_pvalues_log_temp[(full_pvalues_log_temp[,1]<1.84)+(full_pvalues_log_temp[,3]<2.40)>0,]
full_pvalues_log_1=full_pvalues_log_temp[full_pvalues_log_temp[,1]>=1,]
full_pvalues_log_2=full_pvalues_log_temp[full_pvalues_log_temp[,3]>=1,]
text(full_pvalues_log_1[,1],full_pvalues_log_1[,3],labels=rownames(full_pvalues_log_1), cex= 0.7,pos=3)
text(full_pvalues_log_2[,1],full_pvalues_log_2[,3],labels=rownames(full_pvalues_log_2), cex= 0.7,pos=3)

lines(c(-10,2.3),c(1,1),col="green")
lines(c(1,1),c(-10,10),col="green")
#points(full_pvalues_log_sig[,1],full_pvalues_log_sig[,3],col="red",pch = 4)

#highlighting significant processes by filled black square 
for (i in 1:dim(full_pvalues_log_sig)[1])
{
  if (sum(rownames(full_pvalues_log_sig)[i]==rownames(mpvalues))==1)
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="green",pch = 15)
  }
  else if (sum(rownames(full_pvalues_log_sig)[i]==rownames(upvalues))==1)
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="blue",pch = 15)
  }
  else
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="black",pch = 15)
  }
  
}


text(1.845,2.40,label="CLUSTERED",cex=0.8,col = "red")
#moving around labels so they do not overlap 
text(full_pvalues_log[6,1],full_pvalues_log[6,3],label=rownames(full_pvalues_log)[6],cex= 0.7,pos=1)
text(full_pvalues_log[17,1],full_pvalues_log[17,3],label=rownames(full_pvalues_log)[17],cex= 0.7,pos=4)
text(full_pvalues_log[20,1],full_pvalues_log[20,3],label=rownames(full_pvalues_log)[20],cex= 0.7,pos=2)
text(full_pvalues_log[22,1],full_pvalues_log[22,3],label=rownames(full_pvalues_log)[22],cex= 0.7,pos=1)
text(full_pvalues_log[21,1],full_pvalues_log[21,3],label=rownames(full_pvalues_log)[21],cex= 0.7,pos=1)
text(full_pvalues_log[40,1],full_pvalues_log[40,3],label=rownames(full_pvalues_log)[40],cex= 0.7,pos=4)

legend(x=2.3,y=2.6,legend=c('Square=Significant Change','Blue=Unicellular','Green=Multicellular'),title='Colour Codes',cex=0.7)
legend(x=3.075,y=2.2,legend=mu_cluster,title='',cex=0.7)

#removing clustered data 
#note have to rerun the code above to now show clustered gene set names 
clustered_together=full_pvalues_log[(full_pvalues_log[,1]>1.84),]
clustered_together=clustered_together[clustered_together[,3]>2.40,]





plot(full_pvalues_log[,2],full_pvalues_log[,4],xlab="56 day",ylab="100 day",main="-log P values for Mutant vs Wildtype in Processes Underexpressed",xlim=c(0, 2.5),ylim=c(0,2.5))

points(mpvalues[,2],mpvalues[,4],col="green")
points(upvalues[,2],upvalues[,4],col="blue")

full_pvalues_log_temp=full_pvalues_log[-c(33),]
full_pvalues_log_1=full_pvalues_log_temp[full_pvalues_log_temp[,2]>=1,]
full_pvalues_log_2=full_pvalues_log_temp[full_pvalues_log_temp[,4]>=1,]
text(full_pvalues_log_1[,2],full_pvalues_log_1[,4],labels=rownames(full_pvalues_log_1), cex= 0.7,pos=3)
text(full_pvalues_log_2[,2],full_pvalues_log_2[,4],labels=rownames(full_pvalues_log_2), cex= 0.7,pos=3)
lines(c(-10,10),c(1,1),col="green")
lines(c(1,1),c(-10,10),col="green")


for (i in 1:dim(full_pvalues_log_sig)[1])
{
  if (sum(rownames(full_pvalues_log_sig)[i]==rownames(mpvalues))==1)
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="green",pch = 15)
  }
  else if (sum(rownames(full_pvalues_log_sig)[i]==rownames(upvalues))==1)
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="blue",pch = 15)
  }
  else
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="black",pch = 15)
  }
  
}


text(full_pvalues_log[33,2],full_pvalues_log[33,4],label=rownames(full_pvalues_log)[33],cex= 0.7,pos=4)
legend(x=2.1,y=2,legend=c('Square=Significant Change','Blue=Unicellular','Green=Multicellular'),title='Colour Codes',cex=0.7)


