#This script does wilcoxon test analysis for 56 and 100 day samples and produces plots for them. 
#Then goes onto analysis between comparing 56 vs 100 day data
#Analysis of an independent studies normal ventral lobe mouse's prostate expression
#Analysis of potential prostate markers for immune and normal cell contamination 


#Gene Wilcoxon Test


overall_wilcoxon_test=wilcox.test(cpm_wtmutant[,1:4],cpm_wtmutant[,5:8])

#make into a funciton 
gene_age_wilcoxon_test_normal=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]])$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_normal"
  return(gene_age_wilcoxon_test)
}


gene_age_wilcoxon_test_less=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]],alternative ="less")$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_less"
  return(gene_age_wilcoxon_test)
}

gene_age_wilcoxon_test_greater=function(cpm_wtmutant)
{
  gene_age_wilcoxon_test=matrix(0,nrow =dim(cpm_wtmutant)[1],ncol = 1 )
  for (i in 1:dim(cpm_wtmutant)[1])
  {
    gene_age_wilcoxon_test[i]=wilcox.test(cpm_wtmutant[i,1:(dim(cpm_wtmutant)[2]/2)],cpm_wtmutant[i,(dim(cpm_wtmutant)[2]/2+1):dim(cpm_wtmutant)[2]],alternative ="greater")$p.value
  }
  rownames(gene_age_wilcoxon_test)=rownames(cpm_wtmutant)
  colnames(gene_age_wilcoxon_test)="pvalue_greater"
  return(gene_age_wilcoxon_test)
}




#wilcoxon test on genes 

GENE_wilcoxon_normal=gene_age_wilcoxon_test_normal(cpm_wtmutant)
GENE_wilcoxon_normal_greater=gene_age_wilcoxon_test_greater(cpm_wtmutant)
GENE_wilcoxon_normal_less=gene_age_wilcoxon_test_less(cpm_wtmutant)
#Gene Pathway Wilcoxon Test

#_______________________________________________________________
phylostrata_goslim=matrix(0,nrow=length(GOslim_set),ncol=1)
rownames(phylostrata_goslim)=names(GOslim_set)
for (i in 1:length(GOslim_set))
{
  uc=0
  mc=0
  for (j in 1:length(GOslim_set[[names(GOslim_set)[i]]]@geneIds))
  {
    if (sum(GOslim_set[[names(GOslim_set[i])]]@geneIds[j]==Phylostrata[,1])==1)
    {
      if (Phylostrata[GOslim_set[[names(GOslim_set)[i]]]@geneIds[j]==Phylostrata[,1],3]<4)
      {
        uc=uc+1
      }
      else
      {
        mc=mc+1
      }
    }
  }
  if ((uc+mc)>0)
  {
    phylostrata_goslim[i]=uc/(uc+mc)
  }
  else
  {
    phylostrata_goslim[i]=-1
  }
}

colnames( phylostrata_goslim)='uc/(uc+mc)'
goslim_wilcoxon_test_normal=gene_age_wilcoxon_test_normal(gsvaEnrichmentScore_GOslim_set)
goslim_wilcoxon_test_greater=gene_age_wilcoxon_test_greater(gsvaEnrichmentScore_GOslim_set)
goslim_wilcoxon_test_less=gene_age_wilcoxon_test_less(gsvaEnrichmentScore_GOslim_set)
goslim_wilcoxon_test_full=cbind(goslim_wilcoxon_test_normal,goslim_wilcoxon_test_greater,goslim_wilcoxon_test_less,phylostrata_goslim)


greater_uc_mc=goslim_wilcoxon_test_full[goslim_wilcoxon_test_full[,2]<0.1,4]
greater_uc_mc=sum(greater_uc_mc)/length(greater_uc_mc)

less_uc_mc=goslim_wilcoxon_test_full[goslim_wilcoxon_test_full[,3]<0.1,4]
less_uc_mc=sum(less_uc_mc)/length(less_uc_mc)

#__________________________________________________________________-section of code irrelavent 


#graphs 
full_pvalues=read.csv(file="pvalues for wilcoxon test.csv",nrows = 67)

full_pvalues_log=full_pvalues[,2:5]
rownames(full_pvalues_log)=full_pvalues[,1]
full_pvalues_log=-log10(full_pvalues_log)

#significant processes which have changed rank by 20 or more 
full_pvalues_log_sig=c()
for (i in 1:dim(sig56v100)[1])
{
  full_pvalues_log_sig=rbind(full_pvalues_log_sig,full_pvalues_log[rownames(full_pvalues_log)==sig56v100[i],])
}



#locating multicellular and unicellular processes 
mpvalues=c()
upvalues=c()
for (i in 1:67)
{
  if (full_pvalues[i,6]=='m')
  {
    mpvalues=rbind(mpvalues,full_pvalues_log[i,])
  }
  else if (full_pvalues[i,6]=='u')
  {
    upvalues=rbind(upvalues,full_pvalues_log[i,])
  }
}

plot(full_pvalues_log[,1],full_pvalues_log[,3],xlab="56 day",ylab="100 day",main="-log P values for Mutant vs Wildtype in Processes Overexpressed",xlim=c(0, 3.1),ylim=c(0,2.5))
points(mpvalues[,1],mpvalues[,3],col="green") #green dots for multicellular
points(upvalues[,1],upvalues[,3],col="blue")  #blue dots for unicellular 
#there is a group of gene sets that are clustered together 
legend(x=2.3,y=2.2,legend=rownames(clustered_together),title='Clustered',cex=0.7)
#removing overlapping titles 
full_pvalues_log_temp=full_pvalues_log[-c(8,10,14,48,49,20,63,5,60,12,11,30,45),]
full_pvalues_log_temp=full_pvalues_log_temp[(full_pvalues_log_temp[,1]<1.84)+(full_pvalues_log_temp[,3]<2.40)>0,]
full_pvalues_log_1=full_pvalues_log_temp[full_pvalues_log_temp[,1]>=1,]
full_pvalues_log_2=full_pvalues_log_temp[full_pvalues_log_temp[,3]>=1,]
text(full_pvalues_log_1[,1],full_pvalues_log_1[,3],labels=rownames(full_pvalues_log_1), cex= 0.7,pos=3)
text(full_pvalues_log_2[,1],full_pvalues_log_2[,3],labels=rownames(full_pvalues_log_2), cex= 0.7,pos=3)
#producing green significant lines 
lines(c(-10,2.3),c(1,1),col="green")
lines(c(1,1),c(-10,10),col="green")
#points(full_pvalues_log_sig[,1],full_pvalues_log_sig[,3],col="red",pch = 4)

#plotting the significant processes in filled squares
for (i in 1:dim(full_pvalues_log_sig)[1])
{
  if (sum(rownames(full_pvalues_log_sig)[i]==rownames(mpvalues))==1)
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="green",pch = 15)
  }
  else if (sum(rownames(full_pvalues_log_sig)[i]==rownames(upvalues))==1)
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="blue",pch = 15)
  }
  else
  {
    points(full_pvalues_log_sig[i,1],full_pvalues_log_sig[i,3],col="black",pch = 15)
  }
  
}


text(1.845,2.40,label="CLUSTERED",cex=0.8,col = "red")

text(full_pvalues_log[8,1],full_pvalues_log[8,3],label=rownames(full_pvalues_log)[8],cex= 0.7,pos=1)


text(full_pvalues_log[45,1],full_pvalues_log[45,3],label=rownames(full_pvalues_log)[45],cex= 0.7,pos=1)

#moving around labels so they do not overlap

#text(full_pvalues_log[10,1],full_pvalues_log[10,3],label=rownames(full_pvalues_log)[10],cex= 0.7,pos=1)
text(full_pvalues_log[14,1],full_pvalues_log[14,3],label=rownames(full_pvalues_log)[14],cex= 0.7,pos=1)
text(full_pvalues_log[48,1],full_pvalues_log[48,3],label=rownames(full_pvalues_log)[48],cex= 0.7,pos=1)
text(full_pvalues_log[49,1],full_pvalues_log[49,3],label=rownames(full_pvalues_log)[49],cex= 0.7,pos=1)
text(full_pvalues_log[20,1],full_pvalues_log[20,3],label=rownames(full_pvalues_log)[20],cex= 0.7,pos=4)
text(full_pvalues_log[63,1],full_pvalues_log[63,3],label=rownames(full_pvalues_log)[63],cex= 0.7,pos=2)
text(full_pvalues_log[5,1],full_pvalues_log[5,3],label=rownames(full_pvalues_log)[5],cex= 0.7,pos=4)
text(full_pvalues_log[60,1],full_pvalues_log[60,3],label=rownames(full_pvalues_log)[60],cex= 0.7,pos=4)
#text(full_pvalues_log[12,1],full_pvalues_log[12,3],label=rownames(full_pvalues_log)[12],cex= 0.7,pos=4)
#text(full_pvalues_log[11,1],full_pvalues_log[11,3],label=rownames(full_pvalues_log)[11],cex= 0.7,pos=2)
text(full_pvalues_log[30,1],full_pvalues_log[30,3],label=rownames(full_pvalues_log)[30],cex= 0.7,pos=2)

legend(x=2.3,y=2.6,legend=c('Square=Significant Change','Blue=Unicellular','Green=Multicellular'),title='Colour Codes',cex=0.7)
legend(x=3.05,y=2.2,legend=mu_cluster,title='',cex=0.7)

#need to rerun above code to have the clustered_together names appear 
clustered_together=full_pvalues_log[(full_pvalues_log[,1]>1.84),]
clustered_together=clustered_together[clustered_together[,3]>2.40,]

mu_cluster=matrix(0,nrow = dim(clustered_together)[1],ncol = 1)
for (i in 1:dim(clustered_together)[1])
{
  mu_cluster[i]=as.character(full_pvalues[full_pvalues[,1]==rownames(clustered_together)[i],6])
}

plot(full_pvalues_log[,2],full_pvalues_log[,4],xlab="56 day",ylab="100 day",main="-log P values for Mutant vs Wildtype in Processes Underexpressed",xlim=c(0, 2.5),ylim=c(0,2.5))

points(mpvalues[,2],mpvalues[,4],col="green")
points(upvalues[,2],upvalues[,4],col="blue")

full_pvalues_log_temp=full_pvalues_log[-c(9,32,42,59),]
full_pvalues_log_1=full_pvalues_log_temp[full_pvalues_log_temp[,2]>=1,]
full_pvalues_log_2=full_pvalues_log_temp[full_pvalues_log_temp[,4]>=1,]
text(full_pvalues_log_1[,2],full_pvalues_log_1[,4],labels=rownames(full_pvalues_log_1), cex= 0.7,pos=3)
text(full_pvalues_log_2[,2],full_pvalues_log_2[,4],labels=rownames(full_pvalues_log_2), cex= 0.7,pos=3)
lines(c(-10,10),c(1,1),col="green")
lines(c(1,1),c(-10,10),col="green")
#points(full_pvalues_log_sig[,2],full_pvalues_log_sig[,4],col="red",pch = 4)


for (i in 1:dim(full_pvalues_log_sig)[1])
{
  if (sum(rownames(full_pvalues_log_sig)[i]==rownames(mpvalues))==1)
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="green",pch = 15)
  }
  else if (sum(rownames(full_pvalues_log_sig)[i]==rownames(upvalues))==1)
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="blue",pch = 15)
  }
  else
  {
    points(full_pvalues_log_sig[i,2],full_pvalues_log_sig[i,4],col="black",pch = 15)
  }
  
}


text(full_pvalues_log[9,2],full_pvalues_log[9,4],label=rownames(full_pvalues_log)[9],cex= 0.7,pos=1)
text(full_pvalues_log[32,2],full_pvalues_log[32,4],label=rownames(full_pvalues_log)[32],cex= 0.7,pos=4)
text(full_pvalues_log[42,2],full_pvalues_log[42,4],label=rownames(full_pvalues_log)[42],cex= 0.7,pos=1)
text(full_pvalues_log[59,2],full_pvalues_log[59,4],label=rownames(full_pvalues_log)[59],cex= 0.7,pos=4)
legend(x=2.1,y=2.6,legend=c('Square=Significant Change','Blue=Unicellular','Green=Multicellular'),title='Colour Codes',cex=0.7)

#Fisher Exact Test
#determing the total number of multicellular and unicellular processes and the number of multicellular and unicellular 
#processes that are significantly under or over expressed. Then performing a fisher exact test to determine if there is 
#significant difference in unicellular vs multicellular processes being under or overexpressed 
sum_mu=function(full_pvalues) 
{total_u=0
total_m=0
for (i in 1:dim(full_pvalues)[1])
{
  if (full_pvalues[i,6]=="m")
  {total_m=total_m+1}
  else if (full_pvalues[i,6]=="u")
  {total_u=total_u+1}
}
return(c(total_m,total_u))
}

total=sum_mu(full_pvalues)
greater56=sum_mu(full_pvalues[full_pvalues[,2]<=0.1,])
less56=sum_mu(full_pvalues[full_pvalues[,3]<=0.1,])
greater100=sum_mu(full_pvalues[full_pvalues[,4]<=0.1,])
less100=sum_mu(full_pvalues[full_pvalues[,5]<=0.1,])

fisher_greater56=fisher.test(rbind(greater56,total))[["p.value"]]
fisher_less56=fisher.test(rbind(less56,total))[["p.value"]]
fisher_greater100=fisher.test(rbind(greater100,total))[["p.value"]]
fisher_less100=fisher.test(rbind(less100,total))[["p.value"]]




#56vs100 gene analysis 
temp=read.csv(file="56 day results/mouse2human_cpm_wtmutant.csv")
wtmutant56=as.matrix(temp[,2:9])
rownames(wtmutant56)=temp[,1]

temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant2.csv")
wtmutant100=as.matrix(temp[,2:11])
rownames(wtmutant100)=temp[,1]



gene_age_wilcoxon_test_56v100=matrix(0,nrow =length(intersect(rownames(wtmutant100),rownames(wtmutant56))),ncol = 1 )
  
for (i in 1:length(intersect(rownames(wtmutant100),rownames(wtmutant56))))
{
  gene=intersect(rownames(wtmutant100),rownames(wtmutant56))[i]
  gene_age_wilcoxon_test_56v100[i]=wilcox.test(wtmutant100[rownames(wtmutant100)==gene,1:5],wtmutant56[rownames(wtmutant56)==gene,1:4],alternative ="greater")$p.value
}
rownames(gene_age_wilcoxon_test_56v100)=intersect(rownames(wtmutant100),rownames(wtmutant56))
colnames(gene_age_wilcoxon_test_56v100)="pvalue_greater"


#56v100 GOslim analysis 
temp=read.csv(file="ssgsea scores.csv")
ssgsea=as.matrix(temp[,2:19])
rownames(ssgsea)=temp[,1]
#anlaysis on mutants
GOslim_wilcoxon_test_56v100m=matrix(0,nrow=67,ncol = 2 )
for (i in 1:67)
{
  GOslim_wilcoxon_test_56v100m[i,1]=wilcox.test(ssgsea[i,9:13],ssgsea[i,1:4],alternative ="greater")$p.value
  GOslim_wilcoxon_test_56v100m[i,2]=wilcox.test(ssgsea[i,9:13],ssgsea[i,1:4],alternative ="less")$p.value
}
rownames(GOslim_wilcoxon_test_56v100m)=rownames(ssgsea)
colnames(GOslim_wilcoxon_test_56v100m)=c("pvalue_greater","pvalue_less")



#analysis on wildtypes
GOslim_wilcoxon_test_56v100wt=matrix(0,nrow=67,ncol = 2 )
for (i in 1:67)
{
  GOslim_wilcoxon_test_56v100wt[i,1]=wilcox.test(ssgsea[i,14:18],ssgsea[i,5:8],alternative ="greater")$p.value
  GOslim_wilcoxon_test_56v100wt[i,2]=wilcox.test(ssgsea[i,14:18],ssgsea[i,5:8],alternative ="less")$p.value
}
rownames(GOslim_wilcoxon_test_56v100wt)=rownames(ssgsea)
colnames(GOslim_wilcoxon_test_56v100wt)=c("pvalue_greater","pvalue_less")

#Doesn't seem to work well due to normalization??????
#Maybe normalize based on the GOslim processes that remain constant in wildtype and mutant in both timepoints 
constant_GOslims=c()
for (i in 1:dim(full_pvalues)[1])
{
  if (sum(full_pvalues[i,2:5]>0.1)==4)
  {
    constant_GOslims=rbind(constant_GOslims,full_pvalues[i,])
  }
}
names_constant_GOslims= constant_GOslims[,1]
ssgsea_factor=c()
for (i in 1:length(names_constant_GOslims))
{
  a=mean(ssgsea[rownames(ssgsea)==names_constant_GOslims[i],1:4])/mean(ssgsea[rownames(ssgsea)==names_constant_GOslims[i],9:13])
  b=mean(ssgsea[rownames(ssgsea)==names_constant_GOslims[i],5:8])/mean(ssgsea[rownames(ssgsea)==names_constant_GOslims[i],14:18])
  ssgsea_factor=rbind(ssgsea_factor,c(a,b))
}

#Seems quite variable still

#Compare ratios
ratio_ssgsea=matrix(0,nrow=67,ncol=2)
for (i in 1:67)
{
  a=mean(ssgsea[i,1:4])/mean(ssgsea[i,5:8])
  b=mean(ssgsea[i,9:13])/mean(ssgsea[i,14:18])
  ratio_ssgsea[i,]=c(a,b)
}
rownames(ratio_ssgsea)=rownames(ssgsea)

ratio_ssgsea_100v56=matrix(0,nrow=67,ncol=1)
for (i in 1:67)
{
  ratio_ssgsea_100v56[i,1]=ratio_ssgsea[i,2]/ratio_ssgsea[i,1]
}
rownames(ratio_ssgsea_100v56)=rownames(ssgsea)


#Significant 56v100 day changes UP>1.1   DOWN<0.91
UP=ratio_ssgsea_100v56[ratio_ssgsea_100v56>1.1,]
UPm=0
UPu=0
for (i in 1:length(UP)[1])
{
  if (full_pvalues[full_pvalues==names(UP)[i],6]=='m')
  {
    UPm=UPm+1
  }
  else if (full_pvalues[full_pvalues==names(UP)[i],6]=='u')
  {
    UPu=UPu+1
  }
}

fisherUP=fisher.test(rbind(c(UPm,UPu),total))[["p.value"]]
DOWN=ratio_ssgsea_100v56[ratio_ssgsea_100v56<0.91,]
DOWNm=0
DOWNu=0
for (i in 1:length(DOWN)[1])
{
  if (full_pvalues[full_pvalues==names(DOWN)[i],6]=='m')
  {
    DOWNm=DOWNm+1
  }
  else if (full_pvalues[full_pvalues==names(DOWN)[i],6]=='u')
  {
    DOWNu=DOWNu+1
  }
}
fisherDOWN=fisher.test(rbind(c(DOWNm,DOWNu),total))[["p.value"]]


#Compare ranks 
rank56greater=full_pvalues[order(full_pvalues[,2]),1]
rank56less=full_pvalues[order(full_pvalues[,3]),1]
rank100greater=full_pvalues[order(full_pvalues[,4]),1]
rank100less=full_pvalues[order(full_pvalues[,5]),1]

ranks=cbind(rank56greater,rank56less,rank100greater,rank100less)
ranks_names=cbind.data.frame(rank56greater,rank56less,rank100greater,rank100less)
rank_changes=matrix(0,nrow=67,ncol=2)
for (i in 1:67)
{
  a=match(i,order(full_pvalues[,4]))-match(i,order(full_pvalues[,2]))
  b=match(i,order(full_pvalues[,5]))-match(i,order(full_pvalues[,3]))
  rank_changes[i,]=c(-a,-b)
}
rownames(rank_changes)=full_pvalues[,1]
colnames(rank_changes)=c('change in greater','change in less')


#Distribution of rank changes 
boxplot(rank_changes)
hist(rank_changes)


#Ranking of processes
rank_processes=matrix(0,ncol=67,nrow=4)
for (i in 1:67)
{
  a=match(i,order(full_pvalues[,2]))
  b=match(i,order(full_pvalues[,3]))
  c=match(i,order(full_pvalues[,4]))
  d=match(i,order(full_pvalues[,5]))
  rank_processes[,i]=c(a,b,c,d)
}
colnames(rank_processes)=full_pvalues[,1]
rownames(rank_processes)=c("rank56greater","rank56less","rank100greater","rank100less")

write.csv(as.data.frame(rank_processes),file="rank of processes.csv")

#Significant changes in 56 vs 100 day 
sig56v100=c()
for (i in 1:67)
{
  if (sum(abs(rank_changes[i,])>19)>=1)
    sig56v100=rbind(sig56v100,rownames(rank_changes)[i])
}



#Obtaining and analysis of independent study on normal ventral lobe prostate in mice 

read.delim(gzfile("GDS4143_full.soft.gz"), header=T)


library(Biobase)
library(GEOquery)

test=getGEO(file="normal prostate expression/GDS4143_full.soft.gz")

prostate_norm1=matrix(0,nrow=45101,ncol=5)
rownames(prostate_norm1)=genes=test@dataTable@table[["IDENTIFIER"]]
prostate_norm1[,1]=test@dataTable@table[["GSM650476"]]
prostate_norm1[,2]=test@dataTable@table[["GSM650477"]]
prostate_norm1[,3]=test@dataTable@table[["GSM650478"]]
prostate_norm1[,4]=test@dataTable@table[["GSM650479"]]
prostate_norm1[,5]=test@dataTable@table[["GSM650480"]]
####
duplicate_prostate=c()
for (i in 1:length(unique(rownames(prostate_norm1))))
{
  if ( sum(rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i])>1)
  {
    duplicate_prostate=rbind(duplicate_prostate,prostate_norm1[rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i],])
  }
}
#### Seems to be a high variance in duplicate expression values, may need to work with raw data. 


#######----------------------------------------CHECKPOINT
write.csv(as.data.frame(duplicate_prostate), file="duplicate normal prostate expression levels.csv")
temp=read.csv(file="duplicate normal prostate expression levels.csv",header=T)

#_________________________________________

write.csv(as.data.frame(prostate_norm1), file="normal prostate expression/prostate_norm1.csv")
temp=read.csv(file="normal prostate expression/prostate_norm1.csv")
prostate_norm1=temp[,2:6]
for (i in 1:dim(temp)[1])
{
  rownames(prostate_norm1)[i]=as.character(temp[i,1])
}
#ISSUE with duplicate row names 


library(affy)
library(GEOquery)

gse <- getGEO("GSE26464") ##replace XXXX with the GSE number of the dataset you want to download
#You can access the expression data with exprs(gse). Sometimes the dataset was generated using 
#different platforms or batches, so it might be subsettable (e.g. exprs(gse[[1]])).

expression_gse=exprs(gse[[1]])


#download a probe -> gene map file. Let me know if the gene names are not in the file. 
#The map file is available according to the platform.

Data1 <- ReadAffy("normal prostate expression/GSE26464_RAW/GSM650476.CEL.gz")
eset1 <- rma(Data1)
Data2 <- ReadAffy("normal prostate expression/GSE26464_RAW/GSM650477.CEL.gz")
eset2 <- rma(Data2)
Data3 <- ReadAffy("normal prostate expression/GSE26464_RAW/GSM650478.CEL.gz")
eset3 <- rma(Data3)
Data4 <- ReadAffy("normal prostate expression/GSE26464_RAW/GSM650479.CEL.gz")
eset4 <- rma(Data4)
Data5 <- ReadAffy("normal prostate expression/GSE26464_RAW/GSM650480.CEL.gz")
eset5 <- rma(Data5)
expression_data=cbind(eset1@assayData[["exprs"]],eset2@assayData[["exprs"]],eset3@assayData[["exprs"]],eset4@assayData[["exprs"]],eset5@assayData[["exprs"]])
rownames(expression_data)=rownames(prostate_norm1)


unique_expression_data=expression_data[!duplicated(rownames(expression_data)),]


duplicate_expression_data=c()

for (i in 1:length(unique(rownames(prostate_norm1))))
{
  if ( sum(rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i])>1)
  {
    duplicate_expression_data=rbind(duplicate_expression_data,expression_data[rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i],])
  }
}

#just change median to mean if you want average
average_duplicate_expression_data=c()
for (i in 1:length(unique(rownames(prostate_norm1))))
{
  if ( sum(rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i])>1)
  {
    med=matrix(0, nrow=1,ncol=5)
    for (j in 1:5)
    {
      med[1,j]=median(expression_data[rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i],][,j])
    }
    rownames(med)=unique(rownames(prostate_norm1))[i]
    average_duplicate_expression_data=rbind(average_duplicate_expression_data,med)
  }
}

#measure of spread
sd_expression_data=c()

for (i in 1:length(unique(rownames(prostate_norm1))))
{
  if ( sum(rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i])>1)
  {
    sd_expression_data=rbind(sd_expression_data,sd(expression_data[rownames(prostate_norm1)==unique(rownames(prostate_norm1))[i],]))
  }
}
colnames(sd_expression_data)="standard deviation"
rownames(sd_expression_data)=rownames(average_duplicate_expression_data)

overall_expression_data=rbind(average_duplicate_expression_data,unique_expression_data)
overall_expression_data=overall_expression_data[!duplicated(rownames(overall_expression_data)),]

overall_expression_data=overall_expression_data[order(rowMeans(overall_expression_data),decreasing = T),]



#____Potetnial need for normalization of gene length
gene_length=matrix(0,nrow=dim(overall_expression_data)[1],ncol=1)
for (i in 1:dim(overall_expression_data)[1])
{
  if (sum(names(mouse_gene_length)==rownames(overall_expression_data)[i])==1)
  {
    gene_length[i]=mouse_gene_length[names(mouse_gene_length)==rownames(overall_expression_data)[i]]
  }
}
length(gene_length)
no_gene_length=rownames(overall_expression_data)[gene_length==0]
overall_expression_data_norm=overall_expression_data
for (i in 1:length(no_gene_length))
{
  overall_expression_data_norm=overall_expression_data_norm[rownames(overall_expression_data_norm)!=no_gene_length[i],]
}
gene_length=gene_length[gene_length!=0]
names(gene_length)=rownames(overall_expression_data_norm)
normalized_overall_expression_data_norm=rpkm(overall_expression_data_norm,gene.length = as.vector(gene_length),log=TRUE )
normalized_overall_expression_data_norm2=rpkm(overall_expression_data_norm,gene.length = as.vector(gene_length),log=FALSE )









#___________________________________________________
write.csv(as.data.frame(overall_expression_data),file="Comparative Normal Expression Data for Prostate.csv")
temp=read.csv(file="Comparative Normal Expression Data for Prostate.csv", header = T)
overall_expression_data=as.matrix(temp[,2:6])
rownames(overall_expression_data)=temp[,1]
#__________________________________________________________________________

#comparision of ranks of genes in the 56 and 100 day data with the normal data to determine/ have an idea of normal contamination 

temp=read.csv(file="56 day results/mouse_cpm_wtmutant.csv")
day56_expression=as.matrix(temp[,2:9])
rownames(day56_expression)=temp[,1]
day56_expression=day56_expression[order(rowMeans(day56_expression[,5:8]),decreasing = T),]

temp=read.csv(file="100 day results/mouse_normalized_wtmutant2.csv")
day100_expression=as.matrix(temp[,2:11])
rownames(day100_expression)=temp[,1]
day100_expression=day100_expression[order(rowMeans(day100_expression[,6:10]),decreasing = T),]
## Some sort of comparison between the rankings 

rank_comparison=matrix(0,nrow=dim(overall_expression_data)[1],ncol=3)
for (i in 1:dim(overall_expression_data)[1])
{
  rank_comparison[i,1]=i
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day56_expression))))
  {}
  else
  {
    rank_comparison[i,2]=match(rownames(overall_expression_data)[i],rownames(day56_expression))
  }
  rank_comparison[i,1]=i
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day100_expression))))
  {}
  else
  {
    rank_comparison[i,3]=match(rownames(overall_expression_data)[i],rownames(day100_expression))
  }
}

rownames(rank_comparison)=rownames(overall_expression_data)
colnames(rank_comparison)=c('normal','wt 56 day','wt 100 day')

rank_comparison[,1]=rank_comparison[,1]/dim(overall_expression_data)[1]
rank_comparison[,2]=rank_comparison[,2]/dim(day56_expression)[1]
rank_comparison[,3]=rank_comparison[,3]/dim(day100_expression)[1]
rank_comparison_top100=rank_comparison[1:100,]





day56_expression=day56_expression[order(rowMeans(day56_expression[,1:4]),decreasing = T),]
day100_expression=day100_expression[order(rowMeans(day100_expression[,1:5]),decreasing = T),]
rank_comparison_mutant=matrix(0,nrow=dim(overall_expression_data)[1],ncol=3)

for (i in 1:dim(overall_expression_data)[1])
{
  rank_comparison_mutant[i,1]=i
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day56_expression))))
  {}
  else
  {
    rank_comparison_mutant[i,2]=match(rownames(overall_expression_data)[i],rownames(day56_expression))
  }
  rank_comparison_mutant[i,1]=i
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day100_expression))))
  {}
  else
  {
    rank_comparison_mutant[i,3]=match(rownames(overall_expression_data)[i],rownames(day100_expression))
  }
}

rownames(rank_comparison_mutant)=rownames(overall_expression_data)
colnames(rank_comparison_mutant)=c('normal','m 56 day','m 100 day')

rank_comparison_mutant[,1]=rank_comparison_mutant[,1]/dim(overall_expression_data)[1]
rank_comparison_mutant[,2]=rank_comparison_mutant[,2]/dim(day56_expression)[1]
rank_comparison_mutant[,3]=rank_comparison_mutant[,3]/dim(day100_expression)[1]
rank_comparison_top100=rank_comparison[1:100,]

rank_comparison_overall=cbind(rank_comparison,rank_comparison_mutant[,2:3])

relevant_expression_values=matrix(0,nrow=100,ncol=23)
relevant_expression_values[,1:5]=overall_expression_data[1:100,]
for (i in 1:100)
{
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day56_expression))))
  {}
  else
  {
    relevant_expression_values[i,6:13]=day56_expression[match(rownames(overall_expression_data)[i],rownames(day56_expression)),]
  }
  if (is.na(match(rownames(overall_expression_data)[i],rownames(day100_expression))))
  {}
  else
  {
    relevant_expression_values[i,14:23]=day100_expression[match(rownames(overall_expression_data)[i],rownames(day100_expression)),]
  }
}
rownames(relevant_expression_values)=rownames(overall_expression_data)[1:100]
colnames(relevant_expression_values)=c('n1','n2','n3','n4','n5','56m1','56m2','56m3','56m4','56wt1','56wt2','56wt3','56wt4',
                                       '100m1','100m2','100m3','100m4','100m5','100wt1','100wt2','100wt3','100wt4'
                                       ,'100wt5')

write.csv(as.data.frame(rank_comparison_overall),file="comparison of ranks between m,wt and normal.csv")

#top 100 genes quantile analysis 
#top 100 genes expressed in normal data and comparing with 56 and 100 day data 
library(preprocessCore)

quantile_top100= normalize.quantiles(relevant_expression_values,copy=TRUE)

library(quantreg)
rank_comparison_top100_filtered=rank_comparison_overall[rowSums(rank_comparison_overall[,2:5])!=0,]
rank_comparison_top100_filtered=rank_comparison_top100_filtered[1:100,]
x=rank_comparison_top100_filtered[,1]
y=rank_comparison_top100_filtered[,2]
qr56 <- rq(y ~ x, data=data.frame(x,y), tau = 0.4)
summary(qr56)
x=rank_comparison_top100_filtered[,1]
y=rank_comparison_top100_filtered[,3]
qr100 <- rq(y ~ x, data=data.frame(x,y), tau = 0.4)
summary(qr100)

pheatmap(rank_comparison_top100_filtered)




relevant_expression_values_filtered=relevant_expression_values[rowSums(relevant_expression_values[,6:23])!=0,]
write.table( t(as.data.frame(rownames(relevant_expression_values))), file="test51.txt",col.names = F,sep ="\t")
write.table( t(as.data.frame(rownames(relevant_expression_values_filtered))), file="test52.txt",col.names = F,sep ="\t")

library(GSVA)
library(GSEABase)
#producing gene set enrichment score for 56, 100 and normal data with a gene set containing the top 100 expressed genes in the normal data
normal_set<-getGmt('gene sets/prostate normal genes expression levels 2.gmt')

test=as.matrix(relevant_expression_values[,14:23])
rownames(test)=rownames(relevant_expression_values)
gsvaEnrichmentScore_normal_100<-gsva(day100_expression,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_normal_56<-gsva(day56_expression,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_normal_normal<-gsva(overall_expression_data,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)

pheatmap(gsvaEnrichmentScore_normal,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)
colSummarizeAvg(relevant_expression_values_filtered)


#temp=read.csv(file='56 day results/full_results.csv')
#results56=as.matrix(temp[,2])
#rownames(results56)=temp[,1]
#temp=read.csv(file='100 day results/full_results2.csv')
#results100=as.matrix(temp[,2])
#rownames(results100)=temp[,1]

#analysis of log fold change between wildtype and mutant samples in 56 and 100 day timepoints for the top 100 expressed normal genes 
normal100_logFC=matrix(NA,nrow=100,ncol=2)
rownames(normal100_logFC)=rownames(relevant_expression_values)
for (i in 1:100)
{
  if (mean(relevant_expression_values[i,6:9])!=0&&mean(relevant_expression_values[i,10:13])!=0)
  {normal100_logFC[i,1]=log2(mean(relevant_expression_values[i,6:9])/mean(relevant_expression_values[i,10:13]))}
  if(mean(relevant_expression_values[i,14:18])!=0&&mean(relevant_expression_values[i,19:23])!=0)
  {normal100_logFC[i,2]=log2(mean(relevant_expression_values[i,14:18])/mean(relevant_expression_values[i,19:23]))}
}

normal100_logFC=na.omit(normal100_logFC)
colnames(normal100_logFC)=c('56 day','100 day')
colMeans(normal100_logFC)
#Conclude there is less normal contamination from this decrease in average logFC


#### Seems to be a high variance in duplicate expression values, may need to work with raw data. 

#########----------------------------CHECKPOINT
write.csv(as.data.frame(duplicate_expression_data), file="duplicate normal prostate expression levels normalized.csv")
temp=read.csv(file="duplicate normal prostate expression levels normalized.csv",header=T)
#___________________________________________________




#Prostate_marker analysis to determine the quantile rank of these genes and display them in a graph 

prostate_marker_genes=read.csv(file="prostate marker genes.csv",nrows = 6,header = T)
prostate_marker_genes=prostate_marker_genes[,1:4]
day56_expression_marker=matrix(0,nrow = 6,ncol = 8)
day100_expression_marker=matrix(0,nrow = 6,ncol = 10)
overall_expression_data_marker=matrix(0,nrow = 6,ncol = 5)
for (i in 1:6)
{
  day56_expression_marker[i,]=day56_expression[rownames(day56_expression)==prostate_marker_genes[i,4],]
  day100_expression_marker[i,]=day100_expression[rownames(day100_expression)==prostate_marker_genes[i,4],]
  overall_expression_data_marker[i,]=overall_expression_data[rownames(overall_expression_data)==prostate_marker_genes[i,4],]
}

rownames(day56_expression_marker)=prostate_marker_genes[,1]
colnames(day56_expression_marker)=colnames(day56_expression)
rownames(day100_expression_marker)=prostate_marker_genes[,1]
colnames(day100_expression_marker)=colnames(day100_expression)
rownames(overall_expression_data_marker)=prostate_marker_genes[,1]
colnames(overall_expression_data_marker)=colnames(overall_expression_data)


rank_day56_expression=matrix(0,nrow=6,ncol=2)
rank_day100_expression=matrix(0,nrow=6,ncol=2)
rank_overall_expression_data=matrix(0,nrow=6,ncol=1)
for (i in 1:6)
{
  rank_day56_expression[i,1]=match(prostate_marker_genes[i,4],rownames(day56_expression)[order(rowMeans(day56_expression[,1:4]),decreasing = T)])
  rank_day56_expression[i,2]=match(prostate_marker_genes[i,4],rownames(day56_expression)[order(rowMeans(day56_expression[,5:8]),decreasing = T)])
  rank_day100_expression[i,1]=match(prostate_marker_genes[i,4],rownames(day100_expression)[order(rowMeans(day100_expression[,1:5]),decreasing = T)])
  rank_day100_expression[i,2]=match(prostate_marker_genes[i,4],rownames(day100_expression)[order(rowMeans(day100_expression[,6:10]),decreasing = T)])
  rank_overall_expression_data[i,1]=match(prostate_marker_genes[i,4],rownames(overall_expression_data)[order(rowMeans(overall_expression_data),decreasing = T)])
}

rank_day56_expression=rank_day56_expression/dim(day56_expression)[1]
rank_day100_expression=rank_day100_expression/dim(day100_expression)[1]
rank_overall_expression_data=rank_overall_expression_data/dim(overall_expression_data)[1]




rownames(rank_day56_expression)=prostate_marker_genes[,1]
colnames(rank_day56_expression)=c("m","wt")
rownames(rank_day100_expression)=prostate_marker_genes[,1]
colnames(rank_day100_expression)=c("m","wt")
rownames(rank_overall_expression_data)=prostate_marker_genes[,1]
colnames(rank_overall_expression_data)="wt"

par(mfrow=c(3,2)) 
for (i in 1:6)
{
  barplot(rank_day56_expression[i,],main=rownames(rank_day56_expression)[i],ylab='relative rank')
  
}
par(mfrow=c(3,2)) 
for (i in 1:6)
{
  barplot(rank_day100_expression[i,],main=rownames(rank_day100_expression)[i],ylab='relative rank')
  
}
par(mfrow=c(3,2)) 
for (i in 1:6)
{
  temp=cbind(rank_overall_expression_data,rank_day56_expression,rank_day100_expression)
  colnames(temp)=c('normal','56 m','56 wt','100 m','100 wt')
  barplot(temp[i,],main=rownames(temp)[i],ylab='relative rank')
}

#rank 1 looks lower

par(mfrow=c(3,2)) 
for (i in 1:6)
{
  temp=cbind(rank_overall_expression_data,rank_day56_expression,rank_day100_expression,rank_day100_expression_5prime)
  colnames(temp)=c('normal','56 m','56 wt','100 m','100 wt','100 5 m','100 5 wt')
  barplot(1-temp[i,],main=rownames(temp)[i],ylab='relative rank')
}

