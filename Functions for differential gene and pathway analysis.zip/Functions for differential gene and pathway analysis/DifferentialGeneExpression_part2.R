#DifferentialGeneExpression_part2.R     Author:Ethan Grooby    Date:24/11/17
#analysis of the 1000 day data
library(DESeq2)
library(limma)
library(pheatmap)
library(edgeR)
#Read through files
m1<-read.table(file='100 day counts/E38-36.sorted.txt', header=TRUE)
m2<-read.table(file='100 day counts/E38-37.sorted.txt', header=TRUE)
m3<-read.table(file='100 day counts/E38-38.sorted.txt', header=TRUE)
m4<-read.table(file='100 day counts/E38-39.sorted.txt', header=TRUE)
m5<-read.table(file='100 day counts/E38-40.sorted.txt', header=TRUE)
wt1<-read.table(file='100 day counts/E38-11.sorted.txt', header=TRUE)
wt2<-read.table(file='100 day counts/E38-12.sorted.txt', header=TRUE)
wt3<-read.table(file='100 day counts/E38-13.sorted.txt', header=TRUE)
wt4<-read.table(file='100 day counts/E38-14.sorted.txt', header=TRUE)
wt5<-read.table(file='100 day counts/E38-15.sorted.txt', header=TRUE)

#Combine files and add correct row and column names to create the count matrix
fin=nrow(m1)-5
wtmutant<-cbind(m1[1:fin,2],m2[1:fin,2],m3[1:fin,2],m4[1:fin,2],m5[1:fin,2],wt1[1:fin,2],wt2[1:fin,2],wt3[1:fin,2],wt4[1:fin,2],wt5[1:fin,2])
rownames(wtmutant)<- t(wt1[1:fin,1])
colnames(wtmutant) <- c('m1','m2','m3','m4','m5','wt1','wt2','wt3','wt4','wt5')

write.csv(as.data.frame(wtmutant), file="100 day results/complete_count2.csv")

#Filtering out rowSums=0
fwtmutant=wtmutant[rowSums(wtmutant)==0,]
wtmutant=wtmutant[rowSums(wtmutant)>0,]


#gene_length normalization 
library(edgeR)
mouse_info=read.csv(file="mouse_gene_length.csv")

mouse_gene_length=mouse_info[,8]-mouse_info[,7]
names(mouse_gene_length)=mouse_info[,4]



gene_length=matrix(0,nrow=dim(wtmutant)[1],ncol=1)
for (i in 1:dim(wtmutant)[1])
{
  if (sum(names(mouse_gene_length)==rownames(wtmutant)[i])==1)
  {
    gene_length[i]=mouse_gene_length[names(mouse_gene_length)==rownames(wtmutant)[i]]
  }
}
length(gene_length)
no_gene_length=rownames(wtmutant)[gene_length==0]

for (i in 1:length(no_gene_length))
{
  wtmutant=wtmutant[rownames(wtmutant)!=no_gene_length[i],]
}
gene_length=gene_length[gene_length!=0]
names(gene_length)=rownames(wtmutant)
normalized_wtmutant=rpkm(wtmutant,gene.length = as.vector(gene_length),log=TRUE )
normalized_wtmutant2=rpkm(wtmutant,gene.length = as.vector(gene_length),log=FALSE )


############################################################--------CHECKPOINT

write.csv(as.data.frame(wtmutant), file="100 day results/mouse_wtmutant.csv")

temp=read.csv(file="100 day results/mouse_wtmutant.csv")
wtmutant=as.matrix(temp[,2:11])
rownames(wtmutant)=temp[,1]

write.csv(as.data.frame(normalized_wtmutant), file="100 day results/mouse_normalized_wtmutant.csv")

temp=read.csv(file="100 day results/mouse_normalized_wtmutant.csv")
normalized_wtmutant=as.matrix(temp[,2:11])
rownames(normalized_wtmutant)=temp[,1]



write.csv(as.data.frame(normalized_wtmutant2), file="100 day results/mouse_normalized_wtmutant2.csv")

temp=read.csv(file="100 day results/mouse_normalized_wtmutant2.csv")
normalized_wtmutant2=as.matrix(temp[,2:11])
rownames(normalized_wtmutant2)=temp[,1]
#______________________________________________________________________________


#converting mouse gene names to human gene names 

genes_mouse2human_mapped=0
mouse2human=read.csv(file='mouse2human/mouse2human2.csv')
for (i in 1:dim(wtmutant)[1])
{
  if (sum(rownames(wtmutant)[i]==mouse2human[,2])==1)
  {
    genes_mouse2human_mapped=genes_mouse2human_mapped+1
    rownames(wtmutant)[i]=as.character(mouse2human[rownames(wtmutant)[i]==mouse2human[,2],1])
    rownames(normalized_wtmutant)[i]=as.character(mouse2human[rownames(normalized_wtmutant)[i]==mouse2human[,2],1])
    rownames(normalized_wtmutant2)[i]=as.character(mouse2human[rownames(normalized_wtmutant2)[i]==mouse2human[,2],1])
  }
}

unique_wtmutant=unique(rownames(wtmutant[duplicated(rownames(wtmutant)),]))
for (i in 1:length(unique_wtmutant))
{
  wtmutant=wtmutant[rownames(wtmutant) != unique_wtmutant[i], ]
  normalized_wtmutant=normalized_wtmutant[rownames(normalized_wtmutant) != unique_wtmutant[i], ]
  normalized_wtmutant2=normalized_wtmutant2[rownames(normalized_wtmutant2) != unique_wtmutant[i], ]
  gene_length=gene_length[rownames(normalized_wtmutant) != unique_wtmutant[i] ]
}

names(gene_length)=rownames(wtmutant)


write.csv(as.data.frame(wtmutant), file="100 day results/filtered_count2.csv")
write.csv(as.data.frame(fwtmutant), file="100 day results/filtered_out_count2.csv")



############################################################--------CHECKPOINT

write.csv(as.data.frame(wtmutant), file="100 day results/mouse2human_wtmutant.csv")

temp=read.csv(file="100 day results/mouse2human_wtmutant.csv")
wtmutant=as.matrix(temp[,2:11])
rownames(wtmutant)=temp[,1]

write.csv(as.data.frame(normalized_wtmutant), file="100 day results/mouse2human_normalized_wtmutant.csv")

temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant.csv")
normalized_wtmutant=as.matrix(temp[,2:11])
rownames(normalized_wtmutant)=temp[,1]



write.csv(as.data.frame(normalized_wtmutant2), file="100 day results/mouse2human_normalized_wtmutant2.csv")

temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant2.csv")
normalized_wtmutant2=as.matrix(temp[,2:11])
rownames(normalized_wtmutant2)=temp[,1]
#______________________________________________________________________________



#Creating the colData matrix
cdata<-matrix(data=c('m1','m2','m3','m4','m5','wt1','wt2','wt3','wt4','wt5','m','m','m','m','m','wt','wt','wt','wt','wt'),nrow=10)
colnames(cdata)<-c('name','condition')
#Running DESeq and filtering to get overexpressed and underexpressed genees when wild type is compared to the mutant
dds<- DESeqDataSetFromMatrix(countData = wtmutant, colData = cdata, design = ~ condition)
dds$condition <- relevel(dds$condition, ref="wt")
dds <- DESeq(dds) 
res <- results(dds)
resna<-res[is.na(res$padj)==0,]
res1<-resna[resna$padj<0.1,]


#filtered gene set for later use in gsva 
#wtmutantp<-wtmutant[res$pvalue<0.05,]
#wtmutantp<-wtmutantp[is.na(wtmutantp[,1])==0,]
wtmutantpadj<-wtmutant[res$padj<0.1,]
wtmutantpadj<-wtmutantpadj[is.na(wtmutantpadj[,1])==0,]
important_wtmutant<-wtmutantpadj



overexpressed<-res1[res1$log2FoldChange>0,]
overexpressed<-overexpressed[order(overexpressed$padj),]
underexpressed<-res1[res1$log2FoldChange<0,]
underexpressed<-underexpressed[order(underexpressed$padj),]
#Writing to Files 
write.csv(as.data.frame(res), file="100 day results/full_results2.csv")
write.csv(as.data.frame(overexpressed), file="100 day results/overexpressed_results2.csv")
write.csv(as.data.frame(underexpressed), file="100 day results/underexpressed_results2.csv")
#post analysis

#Filtered gene heatmap ordered by expression values 
res1<-res1[order(res1$baseMean,decreasing = TRUE),]
important_wtmutant=wtmutant[rownames(res1),]
rlog_important_wtmutant=rlog(important_wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)

pheatmap(rlog_important_wtmutant,show_rownames=FALSE,cluster_rows=FALSE)


#Top 500 gene changes 
res500<-res1[order((res1$log2FoldChange)^2,decreasing = TRUE),]
res500<-res500[1:500,]

#heatmap for top 500 differentially expressed genes 
test=wtmutant[rownames(res500),]
test<-rlog(test)
pheatmap(test,show_rownames=FALSE,cluster_rows=TRUE)


#Library Size count 
lib_size=colSums(wtmutant)
barplot(lib_size, main="Library Size vs Samples",
        xlab="Samples",ylab="Library Size")
#PSA and MDS plots
vsd <- vst(dds, blind=FALSE)
plotPCA(vsd, intgroup=c("condition")) #1

#GSVA- differential biological pathway analysis


rlog_wtmutant=rlog(wtmutant)
rownames(rlog_wtmutant)=rownames(wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)


library(GSVA)
library(GSEABase)
#Cancer hallmark pathway analysis 
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")



gsvaEnrichmentScore<-gsva(normalized_wtmutant,msigDB50,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore[order(rowSums(gsvaEnrichmentScore),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)

gsvaEnrichmentScore2<-gsva(normalized_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore2[order(rowSums(gsvaEnrichmentScore2),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)



#Proper GOslim analysis 
GOslim_set<-getGmt('gene sets/GOslim_Anna.gmt')
gsvaEnrichmentScore_GOslim_set<-gsva(normalized_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore_GOslim_set[order(rowSums(gsvaEnrichmentScore_GOslim_set),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)


#Proper Phylostrata analysis 100 day- calculation of TAI 

Phylostrata=read.csv(file="Phylostrata.csv")
p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(normalized_wtmutant))==1)
  {
    expression=rbind(expression,normalized_wtmutant[Phylostrata[i,1]==rownames(normalized_wtmutant),]) 
    p_expression=rbind(p_expression,normalized_wtmutant[Phylostrata[i,1]==rownames(normalized_wtmutant),]*Phylostrata[i,3])
  }
}
TAI100_rpkmlog=colSums(p_expression)/colSums(expression)



p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(normalized_wtmutant2))==1)
  {
    expression=rbind(expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]) 
    p_expression=rbind(p_expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]*Phylostrata[i,3])
  }
}
TAI100_rpkm=colSums(p_expression)/colSums(expression)
TAI100_rpkm_summary=matrix(c(mean(TAI100_rpkm[1:5]),mean(TAI100_rpkm[6:10])),ncol=2)
colnames(TAI100_rpkm_summary)=c('m','wt')
rownames(TAI100_rpkm_summary)="TAI"





library(preprocessCore)

quantile_wtmutant= normalize.quantiles(wtmutant,copy=TRUE)
rownames(quantile_wtmutant)=rownames(wtmutant)
colnames(quantile_wtmutant)=colnames(wtmutant)


p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(quantile_wtmutant))==1)
  {
    expression=rbind(expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]) 
    p_expression=rbind(p_expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]*Phylostrata[i,3])
  }
}
TAI100_quantile=colSums(p_expression)/colSums(expression)

TAI100_quantile_summary=matrix(c(mean(TAI100_quantile[1:4]),mean(TAI100_quantile[5:8])),ncol=2)
colnames(TAI100_quantile_summary)=c('m','wt')
rownames(TAI100_quantile_summary)="TAI"



