#Comparing the results of 56 day 3 prime, 100 day normal sequencing and 100 day 3 primed sequencing 

#loading relevant files 

temp=read.csv(file="56 day results/mouse_cpm_wtmutant.csv")
day56_expression=as.matrix(temp[,2:9])
rownames(day56_expression)=temp[,1]
day56_expression=day56_expression[rowMedians(day56_expression)>0,]

temp=read.csv(file="100 day results/mouse_normalized_wtmutant2.csv")
day100_expression=as.matrix(temp[,2:11])
rownames(day100_expression)=temp[,1]
day100_expression=day100_expression[rowMedians(day100_expression)>0,]


temp=read.csv(file="100 day results/mouse_cpm_wtmutant_5prime.csv")
day100_alt=as.matrix(temp[,2:3])
rownames(day100_alt)=temp[,1]

#filtering for all the samples to contain the same genes 
a=intersect(rownames(day56_expression),rownames(day100_expression))
day56_expression_intersect=matrix(0,nrow=length(a),ncol=8)
day100_expression_intersect=matrix(0,nrow=length(a),ncol=10)
day100_alt_intersect=matrix(0,nrow=length(a),ncol=2)
for (i in 1:length(a))
{
  day56_expression_intersect[i,]=day56_expression[match(a[i],rownames(day56_expression)),]
  day100_expression_intersect[i,]=day100_expression[match(a[i],rownames(day100_expression)),]
  day100_alt_intersect[i,]=day100_alt[match(a[i],rownames(day100_alt)),]
}
colnames(day100_expression_intersect)=colnames(day100_expression)
rownames(day100_expression_intersect)=a
colnames(day100_alt_intersect)=colnames(day100_alt)
rownames(day100_alt_intersect)=a
colnames(day56_expression_intersect)=colnames(day56_expression)
rownames(day56_expression_intersect)=a


write.csv(as.data.frame(day56_expression_intersect),file="56 day results/mouse_cpm_wtmutant_intersect.csv")
write.csv(as.data.frame(day100_expression_intersect),file="100 day results/mouse_normalized_wtmutant2_intersect.csv")
write.csv(as.data.frame(day100_alt_intersect),file="100 day results/mouse_day100_alt_intersect.csv")


temp=read.csv(file="56 day results/mouse_cpm_wtmutant_intersect.csv")
day56_expression_intersect=as.matrix(temp[,2:9])
rownames(day56_expression_intersect)=temp[,1]
temp=read.csv(file="100 day results/mouse_normalized_wtmutant2_intersect.csv")
day100_expression_intersect=as.matrix(temp[,2:11])
rownames(day100_expression_intersect)=temp[,1]

temp=read.csv(file="100 day results/mouse_day100_alt_intersect.csv")
day100_alt_intersect=as.matrix(temp[,2:3])
rownames(day100_alt_intersect)=temp[,1]

#converting to human gene names 

mouse2human_fun=function(wtmutant)

{genes_mouse2human_mapped=0
mouse2human=read.csv(file='mouse2human/mouse2human2.csv')
for (i in 1:dim(wtmutant)[1])
{
  if (sum(rownames(wtmutant)[i]==mouse2human[,2])==1)
  {
    genes_mouse2human_mapped=genes_mouse2human_mapped+1
    rownames(wtmutant)[i]=as.character(mouse2human[rownames(wtmutant)[i]==mouse2human[,2],1])
  }
}

unique_wtmutant=unique(rownames(wtmutant[duplicated(rownames(wtmutant)),]))
for (i in 1:length(unique_wtmutant))
{
  wtmutant=wtmutant[rownames(wtmutant) != unique_wtmutant[i], ]
  gene_length=gene_length[rownames(normalized_wtmutant) != unique_wtmutant[i] ]
}

names(gene_length)=rownames(wtmutant)
return(wtmutant)
}
test=mouse2human_fun(day56_expression_intersect)
test2=mouse2human_fun(day100_expression_intersect)
test3=mouse2human_fun(day100_alt_intersect)
write.csv(as.data.frame(test),file="56 day results/mouse2human_cpm_wtmutant_intersect.csv")
write.csv(as.data.frame(test2),file="100 day results/mouse2human_normalized_wtmutant2_intersect.csv")
write.csv(as.data.frame(test3),file="100 day results/mouse2human_day100_alt_intersect.csv")

temp=read.csv(file="56 day results/mouse2human_cpm_wtmutant_intersect.csv")
human_day56_expression_intersect=as.matrix(temp[,2:9])
rownames(human_day56_expression_intersect)=temp[,1]
temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant2_intersect.csv")
human_day100_expression_intersect=as.matrix(temp[,2:11])
rownames(human_day100_expression_intersect)=temp[,1]

temp=read.csv(file="100 day results/mouse2human_day100_alt_intersect.csv")
human_day100_alt_intersect=as.matrix(temp[,2:3])
rownames(human_day100_alt_intersect)=temp[,1]

#function to calculate TAI
Phylostrata_analysis=function(normalized_wtmutant2)
{
  Phylostrata=read.csv(file="Phylostrata.csv")
p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(normalized_wtmutant2))==1)
  {
    expression=rbind(expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]) 
    p_expression=rbind(p_expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]*Phylostrata[i,3])
  }
}
p_expression=p_expression[is.na(p_expression[,1])==0,]
expression=expression[is.na(expression[,1])==0,]
TAI100_rpkm=colSums(p_expression)/colSums(expression)
a=dim(normalized_wtmutant2)[2]
TAI100_rpkm_summary=matrix(c(mean(TAI100_rpkm[1:(a/2)]),mean(TAI100_rpkm[(a/2+1):a])),ncol=2)
colnames(TAI100_rpkm_summary)=c('m','wt')
rownames(TAI100_rpkm_summary)="TAI"
return(TAI100_rpkm_summary)
}

#calculating TAI for all data 
TAI_56=Phylostrata_analysis(human_day56_expression_intersect)
TAI_100=Phylostrata_analysis(human_day100_expression_intersect)
TAI_100_alt=Phylostrata_analysis(human_day100_alt_intersect)

library(GSVA)
library(GSEABase)
normal_set<-getGmt('gene sets/prostate normal genes expression levels 2.gmt')

#calculating the gene enrichment score for the single gene set which contains the top 80 most highly expressed genes in 
#normal prostate ventral lobe obtained in an independent study
gsvaEnrichmentScore_normal_56<-gsva(day56_expression_intersect,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_normal_100<-gsva(day100_expression_intersect,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_normal_100_alt<-gsva(day100_alt_intersect,normal_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)














