#TAI caclulations excluding immune genes 

library(GSVA)
library(GSEABase)
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")
GOslim_set<-getGmt('gene sets/GOslim_Anna.gmt')
#gene sets with immune genes 
a=GOslim_set[["immune.system.process"]]@geneIds
b=msigDB50[["HALLMARK_INTERFERON_ALPHA_RESPONSE"]]@geneIds
c=msigDB50[["HALLMARK_INTERFERON_GAMMA_RESPONSE"]]@geneIds
d=msigDB50[["HALLMARK_IL2_STAT5_SIGNALING"]]@geneIds
e=msigDB50[["HALLMARK_IL6_JAK_STAT3_SIGNALING"]]@geneIds
f=msigDB50[["HALLMARK_ALLOGRAFT_REJECTION"]]@geneIds
g=msigDB50[["HALLMARK_INFLAMMATORY_RESPONSE"]]@geneIds

immune_genes=c(a,b,c,d,e,f,g)
#obtaining the unique set of immune genes 
immune_genes=unique(immune_genes)



#Proper Phylostrata analysis 56 day
temp=read.csv(file="56 day results/mouse2human_cpm_wtmutant.csv")
cpm_wtmutant=as.matrix(temp[,2:9])
rownames(cpm_wtmutant)=temp[,1]


temp=read.csv(file="56 day results/mouse2human_wtmutant.csv")
wtmutant=as.matrix(temp[,2:9])
rownames(wtmutant)=temp[,1]


Phylostrata=read.csv(file="Phylostrata.csv")
cpm_wtmutant=cpm(wtmutant)
p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(cpm_wtmutant))==1)
  {
    #if it is a immune gene skip 
    if (sum(as.character(Phylostrata[i,1])==immune_genes)==1)
    {next}
    expression=rbind(expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]) 
    p_expression=rbind(p_expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_cpm=colSums(p_expression)/colSums(expression)

TAI56_cpm_summary=matrix(c(mean(TAI56_cpm[1:4]),mean(TAI56_cpm[5:8])),ncol=2)
colnames(TAI56_cpm_summary)=c('m','wt')
rownames(TAI56_cpm_summary)="TAI" 




library(preprocessCore)

quantile_wtmutant= normalize.quantiles(wtmutant,copy=TRUE)
rownames(quantile_wtmutant)=rownames(wtmutant)
colnames(quantile_wtmutant)=colnames(wtmutant)


p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(quantile_wtmutant))==1)
  {
    if (sum(as.character(Phylostrata[i,1])==immune_genes)==1)
    {next}
    expression=rbind(expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]) 
    p_expression=rbind(p_expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_quantile=colSums(p_expression)/colSums(expression)

TAI56_quantile_summary=matrix(c(mean(TAI56_quantile[1:4]),mean(TAI56_quantile[5:8])),ncol=2)
colnames(TAI56_quantile_summary)=c('m','wt')
rownames(TAI56_quantile_summary)="TAI"



#Proper Phylostrata analysis 100 day

temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant2.csv")
normalized_wtmutant2=as.matrix(temp[,2:11])
rownames(normalized_wtmutant2)=temp[,1]

temp=read.csv(file="100 day results/mouse2human_wtmutant.csv")
wtmutant=as.matrix(temp[,2:11])
rownames(wtmutant)=temp[,1]




p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(normalized_wtmutant2))==1)
  {
    #if it is an immune gene skip 
    if (sum(as.character(Phylostrata[i,1])==immune_genes)==1)
    {next}
    expression=rbind(expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]) 
    p_expression=rbind(p_expression,normalized_wtmutant2[Phylostrata[i,1]==rownames(normalized_wtmutant2),]*Phylostrata[i,3])
  }
}
TAI100_rpkm=colSums(p_expression)/colSums(expression)
TAI100_rpkm_summary=matrix(c(mean(TAI100_rpkm[1:5]),mean(TAI100_rpkm[6:10])),ncol=2)
colnames(TAI100_rpkm_summary)=c('m','wt')
rownames(TAI100_rpkm_summary)="TAI"

library(preprocessCore)

quantile_wtmutant= normalize.quantiles(wtmutant,copy=TRUE)
rownames(quantile_wtmutant)=rownames(wtmutant)
colnames(quantile_wtmutant)=colnames(wtmutant)


p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(quantile_wtmutant))==1)
  {
    if (sum(as.character(Phylostrata[i,1])==immune_genes)==1)
    {next}
    expression=rbind(expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]) 
    p_expression=rbind(p_expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]*Phylostrata[i,3])
  }
}
TAI100_quantile=colSums(p_expression)/colSums(expression)

TAI100_quantile_summary=matrix(c(mean(TAI100_quantile[1:4]),mean(TAI100_quantile[5:8])),ncol=2)
colnames(TAI100_quantile_summary)=c('m','wt')
rownames(TAI100_quantile_summary)="TAI"