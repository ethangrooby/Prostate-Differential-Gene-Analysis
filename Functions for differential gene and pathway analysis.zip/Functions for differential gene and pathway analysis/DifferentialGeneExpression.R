#DifferentialGeneExpression.R     Author:Ethan Grooby    Date:22/11/17

# analysis of the 56 day data 

library(DESeq2)
library(limma)
library(pheatmap)
library(edgeR)
#Read through files
m1<-read.table(file='56 day counts/BM316-VP-RNA.sorted.txt', header=TRUE)
m2<-read.table(file='56 day counts/BM317-VP-RNA.sorted.txt', header=TRUE)
m3<-read.table(file='56 day counts/BM319-VP-RNA.sorted.txt', header=TRUE)
m4<-read.table(file='56 day counts/BM321-VP-RNA.sorted.txt', header=TRUE)
wt1<-read.table(file='56 day counts/CS9-VP-RNA.sorted.txt', header=TRUE)
wt2<-read.table(file='56 day counts/CS10-VP-RNA.sorted.txt', header=TRUE)
wt3<-read.table(file='56 day counts/CS13-VP-RNA.sorted.txt', header=TRUE)
wt4<-read.table(file='56 day counts/CS297-VP-RNA.sorted.txt', header=TRUE)
#Combine files and add correct row and column names to create the count matrix
fin=nrow(m1)-5
wtmutant<-cbind(m1[1:fin,2],m2[1:fin,2],m3[1:fin,2],m4[1:fin,2],wt1[1:fin,2],wt2[1:fin,2],wt3[1:fin,2],wt4[1:fin,2])
rownames(wtmutant)<- t(wt1[1:fin,1])

#genes_mouse2human_mapped=0
#for (i in 1:dim(wtmutant)[1])
#{
#  if (sum(rownames(wtmutant)[i]==mouse2human[,2])==1)
#  {
#    genes_mouse2human_mapped=genes_mouse2human_mapped+1
#  }
#}


colnames(wtmutant) <- c('m1','m2','m3','m4','wt1','wt2','wt3','wt4')

write.csv(as.data.frame(wtmutant), file="56 day results/complete_count.csv")

#Filtering out rowSums=0
fwtmutant=wtmutant[rowSums(wtmutant)==0,]
wtmutant=wtmutant[rowSums(wtmutant)>0,]


############################################################--------CHECKPOINT
cpm_wtmutant=cpm(wtmutant)

write.csv(as.data.frame(cpm_wtmutant), file="56 day results/mouse_cpm_wtmutant.csv")

temp=read.csv(file="56 day results/mouse_cpm_wtmutant.csv")
cpm_wtmutant=as.matrix(temp[,2:9])
rownames(cpm_wtmutant)=temp[,1]
#______________________________________________________________________________



#converting mouse gene names to human gene names only when there is a one to one relationship
genes_mouse2human_mapped=0
mouse2human=read.csv(file='mouse2human/mouse2human2.csv')
for (i in 1:dim(wtmutant)[1])
{
  if (sum(rownames(wtmutant)[i]==mouse2human[,2])==1)
  {
    genes_mouse2human_mapped=genes_mouse2human_mapped+1
    rownames(wtmutant)[i]=as.character(mouse2human[rownames(wtmutant)[i]==mouse2human[,2],1])
  }
}


unique_wtmutant=unique(rownames(wtmutant[duplicated(rownames(wtmutant)),]))
for (i in 1:length(unique_wtmutant))
{
  wtmutant=wtmutant[rownames(wtmutant) != unique_wtmutant[i], ]
}

############################################################--------CHECKPOINT

write.csv(as.data.frame(wtmutant), file="56 day results/mouse2human_wtmutant.csv")

temp=read.csv(file="56 day results/mouse2human_wtmutant.csv")
wtmutant=as.matrix(temp[,2:9])
rownames(wtmutant)=temp[,1]

cpm_wtmutant=cpm(wtmutant)

write.csv(as.data.frame(cpm_wtmutant), file="56 day results/mouse2human_cpm_wtmutant.csv")

temp=read.csv(file="56 day results/mouse2human_cpm_wtmutant.csv")
cpm_wtmutant=as.matrix(temp[,2:9])
rownames(cpm_wtmutant)=temp[,1]
#______________________________________________________________________________






write.csv(as.data.frame(wtmutant), file="56 day results/filtered_count.csv")
write.csv(as.data.frame(fwtmutant), file="56 day results/filtered_out_count.csv")


#Creating the colData matrix
cdata<-matrix(data=c('m1','m2','m3','m4','wt1','wt2','wt3','wt4','m','m','m','m','wt','wt','wt','wt'),nrow=8)
colnames(cdata)<-c('name','condition')
#Running DESeq and filtering to get overexpressed and underexpressed genees when wild type is compared to the mutant
dds<- DESeqDataSetFromMatrix(countData = wtmutant, colData = cdata, design = ~ condition)
dds$condition <- relevel(dds$condition, ref="wt")
dds <- DESeq(dds) 
res <- results(dds)
resna<-res[is.na(res$padj)==0,]
res1<-resna[resna$padj<0.1,]

write.csv(as.data.frame(res), file="56 day results/DESeq_results.csv")


#filtered gene set for later use in gsva 
#wtmutantp<-wtmutant[res$pvalue<0.05,]
#wtmutantp<-wtmutantp[is.na(wtmutantp[,1])==0,]
wtmutantpadj<-wtmutant[res$padj<0.1,]
wtmutantpadj<-wtmutantpadj[is.na(wtmutantpadj[,1])==0,]
important_wtmutant<-wtmutantpadj



overexpressed<-res1[res1$log2FoldChange>0,]
overexpressed<-overexpressed[order(overexpressed$padj),]
underexpressed<-res1[res1$log2FoldChange<0,]
underexpressed<-underexpressed[order(underexpressed$padj),]
#Writing to Files 
write.csv(as.data.frame(res), file="56 day results/full_results.csv")
write.csv(as.data.frame(overexpressed), file="56 day results/overexpressed_results.csv")
write.csv(as.data.frame(underexpressed), file="56 day results/underexpressed_results.csv")
#post analysis

#Filtered gene heatmap ordered by expression values 
res1<-res1[order(res1$baseMean,decreasing = TRUE),]
important_wtmutant=wtmutant[rownames(res1),]
rlog_important_wtmutant=rlog(important_wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)

pheatmap(rlog_important_wtmutant,show_rownames=FALSE,cluster_rows=FALSE)


#Top 500 gene changes 
res500<-res1[order((res1$log2FoldChange)^2,decreasing = TRUE),]
res500<-res500[1:500,]

#heatmap for top 500 differentially expressed genes 
test=wtmutant[rownames(res500),]
test<-rlog(test)
pheatmap(test,show_rownames=FALSE,cluster_rows=TRUE)


#Library Size count 
lib_size=colSums(wtmutant)
barplot(lib_size, main="Library Size vs Samples",
        xlab="Samples",ylab="Library Size")
#PSA and MDS plots
vsd <- vst(dds, blind=FALSE)
plotPCA(vsd, intgroup=c("condition")) #1

#GSVA- differential biological pathway analysis


rlog_wtmutant=rlog(wtmutant)
rownames(rlog_wtmutant)=rownames(wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)


############################################################--------CHECKPOINT

write.csv(as.data.frame(rlog_wtmutant), file="56 day results/mouse2human_rlogwtmutant.csv")

temp=read.csv(file="56 day results/mouse2human_rlogwtmutant.csv")
rlog_wtmutant=as.matrix(temp[,2:9])
rownames(rlog_wtmutant)=temp[,1]
#______________________________________________________________________________







library(GSVA)
library(GSEABase)
#Cancer hallmark pathway analysis 
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")


gsvaEnrichmentScore<-gsva(rlog_wtmutant,msigDB50,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore[order(rowSums(gsvaEnrichmentScore),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)

gsvaEnrichmentScore2<-gsva(rlog_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore2[order(rowSums(gsvaEnrichmentScore2),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)


#Proper GOslim analysis 
GOslim_set<-getGmt('gene sets/GOslim_Anna.gmt')
gsvaEnrichmentScore_GOslim_set<-gsva(rlog_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore_GOslim_set[order(rowSums(gsvaEnrichmentScore_GOslim_set),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)






#Proper Phylostrata analysis 56 day: Determing the TAI 


Phylostrata=read.csv(file="Phylostrata.csv")
p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(rlog_wtmutant))==1)
  {
    expression=rbind(expression,rlog_wtmutant[Phylostrata[i,1]==rownames(rlog_wtmutant),]) 
    p_expression=rbind(p_expression,rlog_wtmutant[Phylostrata[i,1]==rownames(rlog_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_rlog=colSums(p_expression)/colSums(expression)


cpm_wtmutant=cpm(wtmutant)
p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(cpm_wtmutant))==1)
  {
    expression=rbind(expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]) 
    p_expression=rbind(p_expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_cpm=colSums(p_expression)/colSums(expression)

TAI56_cpm_summary=matrix(c(mean(TAI56_cpm[1:4]),mean(TAI56_cpm[5:8])),ncol=2)
colnames(TAI56_cpm_summary)=c('m','wt')
rownames(TAI56_cpm_summary)="TAI" 




library(preprocessCore)

quantile_wtmutant= normalize.quantiles(wtmutant,copy=TRUE)
rownames(quantile_wtmutant)=rownames(wtmutant)
colnames(quantile_wtmutant)=colnames(wtmutant)


p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(quantile_wtmutant))==1)
  {
    expression=rbind(expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]) 
    p_expression=rbind(p_expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_quantile=colSums(p_expression)/colSums(expression)

TAI56_quantile_summary=matrix(c(mean(TAI56_quantile[1:4]),mean(TAI56_quantile[5:8])),ncol=2)
colnames(TAI56_quantile_summary)=c('m','wt')
rownames(TAI56_quantile_summary)="TAI"







