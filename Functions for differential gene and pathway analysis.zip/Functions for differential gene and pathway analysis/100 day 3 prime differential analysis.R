#Differential gene analysis of the 100 day 3 primed sequenced data


library(DESeq2)
library(limma)
library(pheatmap)
library(edgeR)
#Read through files
wt1<-read.table(file='100 day 3 prime data/E38-11-RNA_htseq_counts.txt', header=TRUE)
m1<-read.table(file='100 day 3 prime data/E38-38a-RNA_htseq_counts.txt', header=TRUE)

#Combine files and add correct row and column names to create the count matrix
fin=nrow(m1)-5
wtmutant<-cbind(m1[1:fin,2],wt1[1:fin,2])
rownames(wtmutant)<- t(wt1[1:fin,1])


colnames(wtmutant) <- c('m1','wt1')

write.csv(as.data.frame(wtmutant), file="100 day results/complete_count_5prime.csv")

#Filtering out rowSums=0
fwtmutant=wtmutant[rowSums(wtmutant)==0,]
wtmutant=wtmutant[rowSums(wtmutant)>0,]


############################################################--------CHECKPOINT
cpm_wtmutant=cpm(wtmutant)

write.csv(as.data.frame(cpm_wtmutant), file="100 day results/mouse_cpm_wtmutant_5prime.csv")

temp=read.csv(file="100 day results/mouse_cpm_wtmutant_5prime.csv")
cpm_wtmutant=as.matrix(temp[,2:3])
rownames(cpm_wtmutant)=temp[,1]
#______________________________________________________________________________


#converting mouse gene names to human gene names only if there is a 1 mouse gene mapping to 1 human gene and vice versa 

genes_mouse2human_mapped=0
mouse2human=read.csv(file='mouse2human/mouse2human2.csv')
for (i in 1:dim(wtmutant)[1])
{
  if (sum(rownames(wtmutant)[i]==mouse2human[,2])==1)
  {
    genes_mouse2human_mapped=genes_mouse2human_mapped+1
    rownames(wtmutant)[i]=as.character(mouse2human[rownames(wtmutant)[i]==mouse2human[,2],1])
  }
}


unique_wtmutant=unique(rownames(wtmutant[duplicated(rownames(wtmutant)),]))
for (i in 1:length(unique_wtmutant))
{
  wtmutant=wtmutant[rownames(wtmutant) != unique_wtmutant[i], ]
}

############################################################--------CHECKPOINT

write.csv(as.data.frame(wtmutant), file="100 day results/mouse2human_wtmutant_5prime.csv")

temp=read.csv(file="100 day results/mouse2human_wtmutant_5prime.csv")
wtmutant=as.matrix(temp[,2:3])
rownames(wtmutant)=temp[,1]

cpm_wtmutant=cpm(wtmutant)

write.csv(as.data.frame(cpm_wtmutant), file="100 day results/mouse2human_cpm_wtmutant_5prime.csv")

temp=read.csv(file="100 day results/mouse2human_cpm_wtmutant_5prime.csv")
cpm_wtmutant=as.matrix(temp[,2:3])
rownames(cpm_wtmutant)=temp[,1]
#______________________________________________________________________________



#Creating the colData matrix
cdata<-matrix(data=c('m1','wt1','m','wt'),nrow=2)
colnames(cdata)<-c('name','condition')
#Running DESeq and filtering to get overexpressed and underexpressed genees when wildtype is compared to the mutant
dds<- DESeqDataSetFromMatrix(countData = wtmutant, colData = cdata, design = ~ condition)
dds$condition <- relevel(dds$condition, ref="wt")
dds <- DESeq(dds) 
res <- results(dds)
resna<-res[is.na(res$padj)==0,]
res1<-resna[resna$padj<0.1,]

write.csv(as.data.frame(res), file="100 day results/DESeq_results_5prime.csv")


#filtered gene set for later use in gsva 
#wtmutantp<-wtmutant[res$pvalue<0.05,]
#wtmutantp<-wtmutantp[is.na(wtmutantp[,1])==0,]
wtmutantpadj<-wtmutant[res$padj<0.1,]
wtmutantpadj<-wtmutantpadj[is.na(wtmutantpadj[,1])==0,]
important_wtmutant<-wtmutantpadj



overexpressed<-res1[res1$log2FoldChange>0,]
overexpressed<-overexpressed[order(overexpressed$padj),]
underexpressed<-res1[res1$log2FoldChange<0,]
underexpressed<-underexpressed[order(underexpressed$padj),]
#Writing to Files 
write.csv(as.data.frame(res), file="100 day results/full_results_5prime.csv")
write.csv(as.data.frame(overexpressed), file="100 day results/overexpressed_results_5prime.csv")
write.csv(as.data.frame(underexpressed), file="100 day results/underexpressed_results_5prime.csv")
#post analysis

#Filtered gene heatmap ordered by expression values 
res1<-res1[order(res1$baseMean,decreasing = TRUE),]
important_wtmutant=wtmutant[rownames(res1),]
rlog_important_wtmutant=rlog(important_wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)

pheatmap(rlog_important_wtmutant,show_rownames=FALSE,cluster_rows=FALSE)



#GSVA- differential biological pathway analysis

#normalizing data based on library size
rlog_wtmutant=rlog(wtmutant)
rownames(rlog_wtmutant)=rownames(wtmutant)
rownames(rlog_important_wtmutant)=rownames(important_wtmutant)


############################################################--------CHECKPOINT

write.csv(as.data.frame(rlog_wtmutant), file="100 day results/mouse2human_rlogwtmutant_5prime.csv")

temp=read.csv(file="100 day results/mouse2human_rlogwtmutant_5prime.csv")
rlog_wtmutant=as.matrix(temp[,2:3])
rownames(rlog_wtmutant)=temp[,1]
#______________________________________________________________________________



library(GSVA)
library(GSEABase)
#Gene enrichment scores for GOslim set
GOslim_set<-getGmt('gene sets/GOslim_Anna.gmt')
gsvaEnrichmentScore_GOslim_set<-gsva(rlog_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
pheatmap(gsvaEnrichmentScore_GOslim_set[order(rowSums(gsvaEnrichmentScore_GOslim_set),decreasing=TRUE),],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)
#Gene enrichment scores for cancer hallmark set
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")
gsvaEnrichmentScore<-gsva(rlog_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)


#Determing the TAI (transcriptome age index)
#rlog and cpm and two different methods of normalizing for gene length 

Phylostrata=read.csv(file="Phylostrata.csv")
p_expression=c()
expression=c()

for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(rlog_wtmutant))==1)
  {
    expression=rbind(expression,rlog_wtmutant[Phylostrata[i,1]==rownames(rlog_wtmutant),]) 
    p_expression=rbind(p_expression,rlog_wtmutant[Phylostrata[i,1]==rownames(rlog_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_rlog=colSums(p_expression)/colSums(expression)


cpm_wtmutant=cpm(wtmutant)
p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(cpm_wtmutant))==1)
  {
    expression=rbind(expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]) 
    p_expression=rbind(p_expression,cpm_wtmutant[Phylostrata[i,1]==rownames(cpm_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_cpm=colSums(p_expression)/colSums(expression)

TAI56_cpm_summary=matrix(c(mean(TAI56_cpm[1:4]),mean(TAI56_cpm[5:8])),ncol=2)
colnames(TAI56_cpm_summary)=c('m','wt')
rownames(TAI56_cpm_summary)="TAI" 



#determing TAI using quantile (relative ranks of genes based on expression) instead of actual expression values 
library(preprocessCore)

quantile_wtmutant= normalize.quantiles(wtmutant,copy=TRUE)
rownames(quantile_wtmutant)=rownames(wtmutant)
colnames(quantile_wtmutant)=colnames(wtmutant)


p_expression=c()
expression=c()
for (i in 1:dim(Phylostrata)[1])
{
  if (sum(as.character(Phylostrata[i,1])==rownames(quantile_wtmutant))==1)
  {
    expression=rbind(expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]) 
    p_expression=rbind(p_expression,quantile_wtmutant[Phylostrata[i,1]==rownames(quantile_wtmutant),]*Phylostrata[i,3])
  }
}
TAI56_quantile=colSums(p_expression)/colSums(expression)

TAI56_quantile_summary=matrix(c(mean(TAI56_quantile[1:4]),mean(TAI56_quantile[5:8])),ncol=2)
colnames(TAI56_quantile_summary)=c('m','wt')
rownames(TAI56_quantile_summary)="TAI"



#Prostate marker analysis
#obtaining the expression values for the prostate marker genes for 56,100 and 100 day 3 prime, and normal 
#prostate expression obtained in an independent study

prostate_marker_genes=read.csv(file="prostate marker genes.csv",nrows = 6,header = T)
prostate_marker_genes=prostate_marker_genes[,1:4]
day56_expression_marker=matrix(0,nrow = 6,ncol = 8)
day100_expression_marker=matrix(0,nrow = 6,ncol = 10)
overall_expression_data_marker=matrix(0,nrow = 6,ncol = 5)
for (i in 1:6)
{
  day56_expression_marker[i,]=day56_expression[rownames(day56_expression)==prostate_marker_genes[i,4],]
  day100_expression_marker[i,]=day100_expression[rownames(day100_expression)==prostate_marker_genes[i,4],]
  overall_expression_data_marker[i,]=overall_expression_data[rownames(overall_expression_data)==prostate_marker_genes[i,4],]
}

rownames(day56_expression_marker)=prostate_marker_genes[,1]
colnames(day56_expression_marker)=colnames(day56_expression)
rownames(day100_expression_marker)=prostate_marker_genes[,1]
colnames(day100_expression_marker)=colnames(day100_expression)
rownames(overall_expression_data_marker)=prostate_marker_genes[,1]
colnames(overall_expression_data_marker)=colnames(overall_expression_data)

#determing the relative rank of the prostate marker genes in the 3 prime 100 day data 
rank_day100_expression_5prime=matrix(0,nrow=6,ncol=2)
for (i in 1:6)
{
  rank_day100_expression_5prime[i,1]=match(prostate_marker_genes[i,4],rownames(cpm_wtmutant)[order(cpm_wtmutant[,1],decreasing = T)])
  rank_day100_expression_5prime[i,2]=match(prostate_marker_genes[i,4],rownames(cpm_wtmutant)[order(cpm_wtmutant[,2],decreasing = T)])

}

rank_day100_expression_5prime=rank_day100_expression_5prime/dim(cpm_wtmutant)[1]

rownames(rank_day100_expression_5prime)=prostate_marker_genes[,1]
colnames(rank_day100_expression_5prime)=c("100 5 prime m","100 5 prime wt")
#displaying the results 
for (i in 1:6)
{
  barplot(1-rank_day100_expression_5prime[i,],main=rownames(rank_day100_expression_5prime)[i],ylab='relative rank')
  
}
