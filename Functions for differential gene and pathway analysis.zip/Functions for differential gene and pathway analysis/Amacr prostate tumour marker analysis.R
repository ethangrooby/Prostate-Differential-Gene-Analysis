#Amacr analysis 
#Amacr is a prostate tumour marker and the relative rank is determined here

#loading required data
temp=read.csv(file="56 day results/mouse_cpm_wtmutant.csv")
day56_expression=as.matrix(temp[,2:9])
rownames(day56_expression)=temp[,1]
day56_expression=day56_expression[order(rowMeans(day56_expression[,5:8]),decreasing = T),]

temp=read.csv(file="100 day results/mouse_normalized_wtmutant2.csv")
day100_expression=as.matrix(temp[,2:11])
rownames(day100_expression)=temp[,1]
day100_expression=day100_expression[order(rowMeans(day100_expression[,6:10]),decreasing = T),]

temp=read.csv(file="Comparative Normal Expression Data for Prostate.csv", header = T)
overall_expression_data=as.matrix(temp[,2:6])
rownames(overall_expression_data)=temp[,1]



#finding the rank of the expression value of this gene 

rank_day56_expression=matrix(0,nrow=1,ncol=2)
rank_day100_expression=matrix(0,nrow=1,ncol=2)

rank_day56_expression[1,1]=match("Amacr",rownames(day56_expression)[order(rowMeans(day56_expression[,1:4]),decreasing = F)])
rank_day56_expression[1,2]=match("Amacr",rownames(day56_expression)[order(rowMeans(day56_expression[,5:8]),decreasing = F)])
rank_day100_expression[1,1]=match("Amacr",rownames(day100_expression)[order(rowMeans(day100_expression[,1:5]),decreasing = F)])
rank_day100_expression[1,2]=match("Amacr",rownames(day100_expression)[order(rowMeans(day100_expression[,6:10]),decreasing = F)])
rank_overall_expression_data=match("Amacr",rownames(overall_expression_data)[order(rowMeans(overall_expression_data),decreasing = F)])

#normalizing based on number of genes
rank_day56_expression=rank_day56_expression/dim(day56_expression)[1]
rank_day100_expression=rank_day100_expression/dim(day100_expression)[1]
rank_overall_expression_data=rank_overall_expression_data/dim(overall_expression_data)[1]




rownames(rank_day56_expression)="Amacr"
colnames(rank_day56_expression)=c("m","wt")
rownames(rank_day100_expression)="Amacr"
colnames(rank_day100_expression)=c("m","wt")

#producing barplot to summarize the data
temp=cbind(rank_overall_expression_data,rank_day56_expression,rank_day100_expression)
colnames(temp)=c('normal','56 m','56 wt','100 m','100 wt')
barplot(temp,main=rownames(temp),ylab='relative rank')


