#Determining if there is a relationship between rRNA content and the %reads mapping to the gene artefact

file_names=list.files("sangkyu_quanseq/htseq/HTSEQ")
test=list()
percentage_artefact=matrix(0,nrow=length(file_names),ncol=2)
rownames(percentage_artefact)=1:length(file_names)
rRNA=read.csv('percentage rRNA.csv')

for (i in 1:length(file_names))
{
  #reading the htseq files
  test=read.table(paste("sangkyu_quanseq/htseq/HTSEQ/",file_names[i],sep = ""))
  test=test[1:(dim(test)[1]-5),]
  #determine the percentage artefact
  percentage_artefact[i,1]=test[test[,1]=="RP23-81C12.3",2]/sum(test[,2])
  rownames(percentage_artefact)[i]=paste(strsplit(file_names[i],split="")[[1]][1:(length(strsplit(file_names[i],split="")[[1]])-11 )],collapse = '')
  #locating the corresponding rRNA content for that sample
  temp=paste(rownames(percentage_artefact)[i],".sorted.bam",sep="")
  percentage_artefact[i,2]=rRNA[rRNA[,1]==temp,11]
  
  }


#ploting %rRNA vs %reads mapping to artefact and the correlation=0.91 
plot(percentage_artefact[,2],percentage_artefact[,1],xlab='% rRNA',ylab='% reads mapping to RP23-81C12.3',main="correlation=0.91")
cor(percentage_artefact[,2],percentage_artefact[,1])
