#This script analyzes the bam files produced from tophat and the counts produced from future counts. To determine whether it was 
#future counts or tophat that has corrected/removed all the reads mapping to the gene artefact 



memory.limit(15000)
library(Rsamtools)
#opening bam files 
tag=c('ZS','NH')
what <- c("pos", "qwidth", "qual","flag","mapq","rname")
param <- ScanBamParam(what=what,tag=tag)
bam_m1<- scanBam("gene artefact correct/BM316-VP-RNA_S45_R1.bam", param=param)
bam_m2 <- scanBam("gene artefact correct/BM317-VP-RNA_S46_R1.bam", param=param)
bam_m3<- scanBam("gene artefact correct/BM319-VP-RNA_S47_R1.bam", param=param)
bam_m4 <- scanBam("gene artefact correct/BM321-VP-RNA_S48_R1.bam", param=param)

bam_wt1 <- scanBam("gene artefact correct/CS9-VP-RNA_S41_R1.bam", param=param)
bam_wt2 <- scanBam("gene artefact correct/CS10-VP-RNA_S42_R1.bam", param=param)
bam_wt3 <- scanBam("gene artefact correct/CS13-VP-RNA_S43_R1.bam", param=param)
bam_wt4 <- scanBam("gene artefact correct/CS297-VP-RNA_S44_R1.bam", param=param)

bam_100=scanBam("gene artefact correct/E38-11-RNA_S49_R1.bam", param=param)

clean=function(bam)
{
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["pos"]]=bam[[1]][["pos"]][is.na(bam[[1]][["pos"]])==0]
  return(bam)
}

#removing NA (unknown) positions 
bam_m1=clean(bam_m1)
bam_m2=clean(bam_m2)
bam_m3=clean(bam_m3)
bam_m4=clean(bam_m4)
bam_wt1=clean(bam_wt1)
bam_wt2=clean(bam_wt2)
bam_wt3=clean(bam_wt3)
bam_wt4=clean(bam_wt4)
bam_100=clean(bam_100)

#function determines the percentage of reads mapping to an area of interest 
area_interest=function(bam,low,high,chr)
{
  temp=bam[[1]][["rname"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  percentage_reads=sum(temp==chr)/length(bam[[1]][["pos"]])
  return(percentage_reads)
}

low=39842997
high=39848829
#low=39847400
#high=39847600

chr="17"
percentage_reads=matrix(0,nrow=9,ncol=1)
rownames(percentage_reads)=c("BM316","BM317","BM319","BM321","CS9","CS10","CS13","CS297","E38-11")
percentage_reads[1,1]=area_interest(bam_m1,low,high,chr)
percentage_reads[2,1]=area_interest(bam_m2,low,high,chr)
percentage_reads[3,1]=area_interest(bam_m3,low,high,chr)
percentage_reads[4,1]=area_interest(bam_m4,low,high,chr)
percentage_reads[5,1]=area_interest(bam_wt1,low,high,chr)
percentage_reads[6,1]=area_interest(bam_wt2,low,high,chr)
percentage_reads[7,1]=area_interest(bam_wt3,low,high,chr)
percentage_reads[8,1]=area_interest(bam_wt4,low,high,chr)
percentage_reads[9,1]=area_interest(bam_100,low,high,chr)

#this function filters the bam file to only the area of interest 
bam_focus=function(bam,low,high,chr)
{
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["pos"]]= bam[[1]][["pos"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["pos"]]= bam[[1]][["pos"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][bam[[1]][["rname"]]==chr]
  return(bam)
}

low=39847400
high=39847600

bam_m1=bam_focus(bam_m1,low,high,chr)
bam_m2=bam_focus(bam_m2,low,high,chr)
bam_m3=bam_focus(bam_m3,low,high,chr)
bam_m4=bam_focus(bam_m4,low,high,chr)
bam_wt1=bam_focus(bam_wt1,low,high,chr)
bam_wt2=bam_focus(bam_wt2,low,high,chr)
bam_wt3=bam_focus(bam_wt3,low,high,chr)
bam_wt4=bam_focus(bam_wt4,low,high,chr)
bam_100=bam_focus(bam_100,low,high,chr)
#producing converage plots 
par(mfrow=c(5,2))
hist(bam_m1[[1]][["pos"]],xlab="gene position", ylab="frequency",main="BM316",xlim=c(low,high),breaks=100)
hist(bam_m2[[1]][["pos"]],xlab="gene position", ylab="frequency",main="BM317",xlim=c(low,high),breaks=100)
hist(bam_m3[[1]][["pos"]],xlab="gene position", ylab="frequency",main="BM319",xlim=c(low,high),breaks=100)
hist(bam_m4[[1]][["pos"]],xlab="gene position", ylab="frequency",main="BM321",xlim=c(low,high),breaks=100)
hist(bam_wt1[[1]][["pos"]],xlab="gene position", ylab="frequency",main="CS9",xlim=c(low,high),breaks=100)
hist(bam_wt2[[1]][["pos"]],xlab="gene position", ylab="frequency",main="CS10",xlim=c(low,high),breaks=100)
hist(bam_wt3[[1]][["pos"]],xlab="gene position", ylab="frequency",main="CS13",xlim=c(low,high),breaks=100)
hist(bam_wt4[[1]][["pos"]],xlab="gene position", ylab="frequency",main="CS297",xlim=c(low,high),breaks=100)
hist(bam_100[[1]][["pos"]],xlab="gene position", ylab="frequency",main="E38-11",xlim=c(low,high),breaks=100)

#loading 56 and 100 day 3 prime sequenced data done with htseq to compare with the correspoinding 56 and 100 day data done with future counts 
temp=read.csv("56 day results/complete_count.csv")
wtmutant56=temp[,2:9]
rownames(wtmutant56)=temp[,1]

temp=read.csv("100 day results/complete_count_5prime.csv")
wtmutant100=temp[,2:3]
rownames(wtmutant100)=temp[,1]

future_counts=read.csv("gene artefact correct/FeatureCountsAllSamplesMatrix.csv")

future_counts[future_counts[,1]=="RP23-81C12.3",]
#does not exist        RP23-81C12.2 does
#

#removing all genes with zero reads 
wtmutant56=wtmutant56[rowSums(wtmutant56)>0,]
wtmutant100=wtmutant100[rowSums(wtmutant100)>0,]
future_counts=future_counts[rowSums(future_counts[,2:10])>0,]

#rearranging the layout of future count to correspond with the the columns of the wtmutant56 and wtmutant100
temp=future_counts[,5]
temp2=future_counts[,c(2:4,6:10)]
future_counts[,2:10]=cbind(temp,temp2)
colnames(future_counts)[2:10]=colnames(future_counts[,c(5,2:4,6:10)])

#determining the indices of where the future counts and the wtmutant data have the same genes 
i_f=match(rownames(wtmutant56),future_counts[,1])
i_56=match(future_counts[,1],rownames(wtmutant56))
i_f=i_f[is.na(i_f)==0]
i_56=i_56[is.na(i_56)==0]

i_f2=match(rownames(wtmutant100),future_counts[,1])
i_100=match(future_counts[,1],rownames(wtmutant100))
i_f2=i_f2[is.na(i_f2)==0]
i_100=i_100[is.na(i_100)==0]

#producing 3 rows of data 
#first row is the total number of reads in the future count data for the genes that are also present in the htseq data
#second row is the total number of reads in the htseq count data for the genes that are also present in the future count data
#third row is the total number of reads in the htseq count data that map to the gene artefact
htseq_total_reads=c(colSums(wtmutant56[i_56,]),sum(wtmutant100[i_100,2]))
htseq_RP23=c(wtmutant56[rownames(wtmutant56)=="RP23-81C12.3",],wtmutant100[rownames(wtmutant100)=="RP23-81C12.3",2])
future_counts_total_reads=c(colSums(future_counts[i_f,2:9]),sum(future_counts[i_f2,10]))
rbind(future_counts_total_reads,htseq_total_reads,htseq_RP23)

#filtering the future counts and htseq data for only genes they have in common
filtered_f_56=future_counts[i_f,2:9]
rownames(filtered_f_56)=future_counts[i_f,1]
filtered_f_100=future_counts[i_f2,10]
names(filtered_f_100)=future_counts[i_f2,1]
filtered_56=wtmutant56[match(rownames(filtered_f_56),rownames(wtmutant56)),]
filtered_100=wtmutant100[match(names(filtered_f_100),rownames(wtmutant100)),2]

#determining the correlation between the htseq and future count data by compairing gene vs gene counts 

cor(filtered_f_100,filtered_100)
correlation=matrix(0,nrow=8,ncol=1)
rownames(correlation)=colnames(filtered_f_56)
for (i in 1:8)
{
  correlation[i]=cor(filtered_f_56,filtered_56)[i,i]
}


