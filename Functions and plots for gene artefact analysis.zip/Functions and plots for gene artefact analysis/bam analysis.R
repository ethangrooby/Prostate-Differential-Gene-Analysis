#Analysis of the bam files produced by hisat 

library(Rsamtools)
#obtaining the bam files with the desired information 
#rname=chromosome of the read , pos=position of read, mapq=mapping quality, NH=number of hits= number of possible alignments for this read, 
#ZS= alignment score for next best alignment if existent,

tag=c('ZS','NH')
what <- c("pos", "qwidth", "qual","flag","mapq","rname")
param <- ScanBamParam(what=what,tag=tag)
bam_m1<- scanBam("Bam Files/BM316-VP-RNA.sorted.bam", param=param)
bam_m2 <- scanBam("Bam Files/BM317-VP-RNA.sorted.bam", param=param)
bam_wt1 <- scanBam("Bam Files/CS9-VP-RNA.sorted.bam", param=param)
bam_wt2 <- scanBam("Bam Files/CS10-VP-RNA.sorted.bam", param=param)

#function to remove all the NA values (reads with no location mapped)
clean=function(bam)
{
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][is.na(bam[[1]][["pos"]])==0]
  bam[[1]][["pos"]]=bam[[1]][["pos"]][is.na(bam[[1]][["pos"]])==0]
  return(bam)
}
#function to narrow to area of interest for analysis 
bam_focus=function(bam,low,high,chr)
{
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  bam[[1]][["pos"]]= bam[[1]][["pos"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  
  bam[[1]][["qwidth"]]=bam[[1]][["qwidth"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["qual"]]=bam[[1]][["qual"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["mapq"]]=bam[[1]][["mapq"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["flag"]]=bam[[1]][["flag"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["tag"]][["NH"]]=bam[[1]][["tag"]][["NH"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["tag"]][["ZS"]]=bam[[1]][["tag"]][["ZS"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["pos"]]= bam[[1]][["pos"]][bam[[1]][["rname"]]==chr]
  bam[[1]][["rname"]]=bam[[1]][["rname"]][bam[[1]][["rname"]]==chr]
  
  return(bam)
}

bam_m1=clean(bam_m1)
bam_m2=clean(bam_m2)
bam_wt1=clean(bam_wt1)
bam_wt2=clean(bam_wt2)

low=39842997
high=39848829
chr="17"
bam_m1=bam_focus(bam_m1,low,high,chr)
bam_m2=bam_focus(bam_m2,low,high,chr)
bam_wt1=bam_focus(bam_wt1,low,high,chr)
bam_wt2=bam_focus(bam_wt2,low,high,chr)

#producing a converage plot for the area of interest 
par(mfrow=c(2,2))
hist(bam_m1[[1]][["pos"]],xlab="gene position", ylab="frequency",main="m1")
hist(bam_m2[[1]][["pos"]],xlab="gene position", ylab="frequency",main="m2")
hist(bam_wt1[[1]][["pos"]],xlab="gene position", ylab="frequency",main="wt1")
hist(bam_wt2[[1]][["pos"]],xlab="gene position", ylab="frequency",main="wt2")

low=39847400
high=39847600
bam_m1_f=bam_focus(bam_m1,low,high.chr)
bam_m2_f=bam_focus(bam_m2,low,high,chr)
bam_wt1_f=bam_focus(bam_wt1,low,high,chr)
bam_wt2_f=bam_focus(bam_wt2,low,high,chr)

par(mfrow=c(2,2))
hist(bam_m1_f[[1]][["pos"]],xlab="gene position", ylab="frequency",main="m1")
hist(bam_m2_f[[1]][["pos"]],xlab="gene position", ylab="frequency",main='m2')
hist(bam_wt1_f[[1]][["pos"]],xlab="gene position", ylab="frequency",main="wt1")
hist(bam_wt2_f[[1]][["pos"]],xlab="gene position", ylab="frequency",main='wt2')

#determing the mapping quality 
bam_analysis=function(bam_m1)
{
  quality=matrix(0,nrow=length(bam_m1[[1]][['qual']]),ncol=1)
  for (i in 1:length(bam_m1[[1]][['qual']]))
  {
    quality[i]=mean(utf8ToInt(as.character(bam_m1[[1]][["qual"]][[i]])))
  }
  quality=mean(quality)+33
  map_quality=mean(bam_m1[[1]][["mapq"]])
  multiple_mapping=sum(bam_m1[[1]][["flag"]]==64)+sum(bam_m1[[1]][["flag"]]==128)
  results=c(quality,map_quality,multiple_mapping)
  names(results)=c('quality','map quality','multiple mapping ')
  return(results)
}

#determine the average multiple hits and the average alignment score for the next best alignment 
bam_mulitple=function(bam)
{
  multiple_hits=mean(bam[[1]][["tag"]][["NH"]])
  next_best=c(sum(is.na(bam[[1]][["tag"]][["ZS"]]))/length(bam[[1]][["tag"]][["ZS"]]),mean(bam[[1]][["tag"]][["ZS"]][is.na(bam[[1]][["tag"]][["ZS"]])==0]))
  result=c(multiple_hits,next_best)
  names(result)=c('avg. multiple hits','% NA','avg. next best score')
  return(result)
  }

multiple_m1=bam_mulitple(bam_m1)
multiple_m2=bam_mulitple(bam_m2)
multiple_wt1=bam_mulitple(bam_wt1)
multiple_wt2=bam_mulitple(bam_wt2)



result_m1=bam_analysis(bam_m1)
result_m2=bam_analysis(bam_m2)
result_wt1=bam_analysis(bam_wt1)
result_wt2=bam_analysis(bam_wt2)
total_reads=c(length(bam_m1[[1]][["pos"]]),length(bam_m2[[1]][["pos"]]),length(bam_wt1[[1]][["pos"]]),length(bam_wt2[[1]][["pos"]]))


#determing what normal mapping quality, multiple hit scores and next best alignment scores look like
library(GSVA)
library(GSEABase)
#list of the top 80 top expressed genes in a normal ventral lobe prostate in a mouse
normal_set<-getGmt('gene sets/prostate normal genes expression levels 2.gmt')


gene_locations=read.csv(file="mouse_gene_locations.csv",header=T)
#finding the location of all the genes 
normal_locations=matrix(0,nrow = 80,ncol=2)
rownames(normal_locations)=normal_set[["Normal"]]@geneIds
for (i in 1:80)
{
  normal_locations[i,]=as.matrix(gene_locations[match(normal_set[["Normal"]]@geneIds[i],gene_locations[,1]),2:3])
}
colnames(normal_locations)=c("start","end")

#get mapping quality 
#note needs to be edited to filter for particular chromosome potentially 
map_quality=matrix(0,nrow=80,ncol=4)
for (i in 1:80)
{
  high=normal_locations[i,2]
  low=normal_locations[i,1]
  map_quality[i,1]=mean(bam_m1[[1]][["mapq"]][((bam_m1[[1]][["pos"]]>low)+(bam_m1[[1]][["pos"]]<high))==2])
  map_quality[i,2]=mean(bam_m2[[1]][["mapq"]][((bam_m2[[1]][["pos"]]>low)+(bam_m2[[1]][["pos"]]<high))==2])
  map_quality[i,3]=mean(bam_wt1[[1]][["mapq"]][((bam_wt1[[1]][["pos"]]>low)+(bam_wt1[[1]][["pos"]]<high))==2])
  map_quality[i,4]=mean(bam_wt2[[1]][["mapq"]][((bam_wt2[[1]][["pos"]]>low)+(bam_wt2[[1]][["pos"]]<high))==2])
  
}




#get average multiple hits and next best alignment score
#note needs to be edited to filter for particular chromosome potentially 
normal_map_multiple_fun=function(bam)
{
normal_map_multiple=matrix(0,nrow=80,ncol=3)
colnames(normal_map_multiple)=c('avg. multiple hits','% NA','avg. next best score')
for (i in 1:80)
{
  high=normal_locations[i,2]
  low=normal_locations[i,1]
  
  temp_NH=bam[[1]][["tag"]][["NH"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  temp_ZS=bam[[1]][["tag"]][["ZS"]][((bam[[1]][["pos"]]>low)+(bam[[1]][["pos"]]<high))==2]
  multiple_hits=mean(temp_NH)
  next_best=c(sum(is.na(temp_ZS))/length(temp_ZS),mean(temp_ZS[is.na(temp_ZS)==0]))
  result=c(multiple_hits,next_best)
  normal_map_multiple[i,]=result
}
return(normal_map_multiple)
}
normal_multiple_m1=normal_map_multiple_fun(bam_m1)
normal_multiple_m2=normal_map_multiple_fun(bam_m2)
normal_multiple_wt1=normal_map_multiple_fun(bam_wt1)
normal_multiple_wt2=normal_map_multiple_fun(bam_wt2)




#determine the number of reads in a particular area of interest 
bam_length=matrix(0,nrow=2,ncol=4)
low=39846352	
high=39848201
bam_length[1,1]=length(bam_m1[[1]][["mapq"]][((bam_m1[[1]][["pos"]]>low)+(bam_m1[[1]][["pos"]]<high))==2])
bam_length[1,2]=length(bam_m2[[1]][["mapq"]][((bam_m2[[1]][["pos"]]>low)+(bam_m2[[1]][["pos"]]<high))==2])
bam_length[1,3]=length(bam_wt1[[1]][["mapq"]][((bam_wt1[[1]][["pos"]]>low)+(bam_wt1[[1]][["pos"]]<high))==2])
bam_length[1,4]=length(bam_wt2[[1]][["mapq"]][((bam_wt2[[1]][["pos"]]>low)+(bam_wt2[[1]][["pos"]]<high))==2])
low=39842997
high=39848829
bam_length[2,1]=length(bam_m1[[1]][["mapq"]][((bam_m1[[1]][["pos"]]>low)+(bam_m1[[1]][["pos"]]<high))==2])
bam_length[2,2]=length(bam_m2[[1]][["mapq"]][((bam_m2[[1]][["pos"]]>low)+(bam_m2[[1]][["pos"]]<high))==2])
bam_length[2,3]=length(bam_wt1[[1]][["mapq"]][((bam_wt1[[1]][["pos"]]>low)+(bam_wt1[[1]][["pos"]]<high))==2])
bam_length[2,4]=length(bam_wt2[[1]][["mapq"]][((bam_wt2[[1]][["pos"]]>low)+(bam_wt2[[1]][["pos"]]<high))==2])

