#analysis of the bluebee pipeline data to see the %reads mapping to the gene artefact area 

library(edgeR)
#reading all the files 
m1_56=read.table(file="bluebee/bsc_output/BM321-VP-RNA_S48_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-ff3dbb63-e860-4ca5-9f38-0b1bdfaede4d_output-folder/star_out/BM321-VP-RNA_S48_R1_001.fastq.gz/read_counts.txt")
m2_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-BM316-VP-RNA_S45_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-62672df4-76b2-4d20-8f87-a512efa7b146_output-folder/star_out/BM316-VP-RNA_S45_R1_001.fastq.gz/read_counts.txt")
m3_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-BM317-VP-RNA_S46_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-956dbbc3-238e-42fe-a696-3b094362d3db_output-folder/star_out/BM317-VP-RNA_S46_R1_001.fastq.gz/read_counts.txt")
m4_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-BM319-VP-RNA_S47_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-900ce1ec-871b-463a-8e70-36b15b8f8323_output-folder/star_out/BM319-VP-RNA_S47_R1_001.fastq.gz/read_counts.txt")
wt1_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-CS9-VP-RNA_S41_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-9a1299de-412a-4768-bea3-a480fa0a9eca_output-folder/star_out/CS9-VP-RNA_S41_R1_001.fastq.gz/read_counts.txt")
wt2_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-CS10-VP-RNA_S42_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-80ffc56d-6026-448e-9c74-0c61ae5323c3_output-folder/star_out/CS10-VP-RNA_S42_R1_001.fastq.gz/read_counts.txt")
wt3_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-CS13-VP-RNA_S43_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-6b8ba739-14c2-474d-88a1-6118edfa3068_output-folder/star_out/CS13-VP-RNA_S43_R1_001.fastq.gz/read_counts.txt")
wt4_56=read.table(file="bluebee/bsc_output/dg_mm10_batched-CS297-VP-RNA_S44_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-fd13d08e-93e3-48b0-ad83-df3e0f3b2d75_output-folder/star_out/CS297-VP-RNA_S44_R1_001.fastq.gz/read_counts.txt")
wt1_100=read.table(file="bluebee/bsc_output/dg_mm10_batched-E38-11-RNA_S49_R1_001_fastq_gz-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-88a032a0-446f-440f-8d2e-9536f5856e4a_output-folder/star_out/E38-11-RNA_S49_R1_001.fastq.gz/read_counts.txt")
m1_100=read.table(file="bluebee/bsc_output/dg_mm10-Mouse__GRCm38__Lexogen_QuantSeq_2_2_FWD-10cec8b1-cb8e-4101-a4e3-a4a579cc5942_output-folder/star_out/E38-38a-RNA_S50_R1_001.fastq.gz/read_counts.txt")
fin=nrow(m1_56)-5
day56_bluebee=cbind(m1_56[1:fin,2],m2_56[1:fin,2],m3_56[1:fin,2],m4_56[1:fin,2],wt1_56[1:fin,2],wt2_56[1:fin,2],wt3_56[1:fin,2],wt4_56[1:fin,2])
rownames(day56_bluebee)=m1_56[1:fin,1]
day56_bluebee=cpm(day56_bluebee)
#determining the percentage of reads mappings to the artefact in both the 56 and 100 day data 
percentage_artifact_56=day56_bluebee[rownames(day56_bluebee)=='ENSMUSG00000098178',]/colSums(day56_bluebee)


day100_bluebee=cbind(m1_100[1:fin,2],wt1_100[1:fin,2])
rownames(day100_bluebee)=m1_100[1:fin,1]
day100_bluebee=cpm(day100_bluebee)
percentage_artifact_100=day100_bluebee[rownames(day100_bluebee)=='ENSMUSG00000098178',]/colSums(day100_bluebee)
#corresponding file names to variable names 
#BM321 BM316 BM317 BM319 CS9    CS10    CS13    CS297   E38-38a E38-11
#m1_56 m2_56 m3_56 m4_56 wt1_56 wt2_56  wt3_56  wt4_56  m1_100  wt1_100
