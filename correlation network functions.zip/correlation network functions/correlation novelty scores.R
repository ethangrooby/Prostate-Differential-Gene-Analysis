#Determine the:
#Similarity results for normal modules as compared with the tumour modules. Where the similarity values are number of genes 
#in common divided total genes in the normal module. 

#Novelty scores where it is the number of normal modules required to reach at least 50% similarity in the tumour modules.

#False runs- which is a list of the novelty and similarity results which probably should be excluded as 
#either the tumour or normal run through only produced one module. 


#Determining the similarity results 


#Setting up variables to run through
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")

#loading the original cluster assignemtns 
load("overall_cluster_assignments.Rdata")
similarity_nvt=list()
for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      full_set=overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]]
      subset=overall_cluster_assignemtns[["tumour"]][[paste(t,s,n,sep='_')]]

      #comparing original set with subset similarity. Similarity score defined as no. genes in both module sets 
      #divided by total genes in the original module set
      
      similarity=matrix(0,nrow=length(full_set),ncol=length(subset))
      rownames(similarity)=names(full_set)
      colnames(similarity)=names(subset)
      for (i in 1:length(full_set))
      {
        for (j in 1:length(subset))
        {
          similarity[i,j]=length(intersect(full_set[[i]],subset[[j]]))/length(full_set[[i]])
        }
      }

      similarity_nvt[[t]][[paste(s,n,sep='_')]]=similarity
    }
  }
}



save(similarity_nvt,file="similarity_nvt.Rdata")

#Generating the novelty scores 
novelty=list()

for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      temp=matrix(0,nrow=dim((similarity_nvt[[t]][[paste(s,n,sep='_')]]))[2],ncol=1)
      #count stores the cumulative sum of the similarity scores from descending order to determine what is the smallest i value
      #to reach 50% similarity 
      for (j in 1:dim(similarity_nvt[[t]][[paste(s,n,sep='_')]])[2])
      {
        count=0
        sorted_sim=sort(similarity_nvt[[t]][[paste(s,n,sep='_')]][,j],decreasing = T)
        for (i in 1:dim(similarity_nvt[[t]][[paste(s,n,sep='_')]])[1])
        {
          count=count+sorted_sim[i]
          if (count>=0.5)
          {
            novel=i
            break 
          }
        }
        temp[j]=novel
      }
      #storing all the novelty scores 
      #note there is an issue with the code where when you get to COAD_0.5_1 it cannot place it in the list. I believe the issue is due to
      # COAD_0.25_1 and COAD_0.25_2 being miss runs that result in producing only 1 similarity score instead of a list of similarity scores. Thus causing 
      # a restricting in all COAD inputs needing to be a single integer and not a list. Current solution is to run COAD_0.5_1 first and then run everything 
      #else. 
      novelty[[t]][[paste(s,n,sep='_')]]=temp
    }
  }

}

save(novelty,file="novelty.Rdata")

#producing a list of the run that are miss runs which suggests the novelty scores for these run throughs should be ignored  
false_runs=list()
count=0
for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      a=length(overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]])
      b=length(overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]])
      
      if (a==1 || b==1)
      { count=count+1
        false_runs[[count]]=paste(t,s,n,sep="_")
      }
    }
  }
}
save(false_runs,file="false_runs.Rdata")
