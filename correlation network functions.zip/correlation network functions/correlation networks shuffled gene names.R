#Generating cluster assignments produced from shuffling the gene names for the expression set.
#Then to determine the similarity between these randomly generated shuffled subsets as compared with the original cluster assignments 


#correlation networks shuffled gene names
load("Correlation Networks/cluster_assignments.Rdata")
load("Correlation Networks/expression_WGCNA_paired.Rdata")

shuffled_expression_WGCNA=expression_WGCNA
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
sample_type=c("normal","tumour")


for (t in tumours)
{
  for (st in sample_type)
  {
    colnames(shuffled_expression_WGCNA[[st]][[t]])=sample(colnames(expression_WGCNA[[st]][[t]]))
  }
}


save(shuffled_expression_WGCNA,file='shuffled_expression_WGCNA.Rdata')

#Producing cluster assignments
library(WGCNA)

load('shuffled_expression_WGCNA.Rdata')
expression_WGCNA_overall=shuffled_expression_WGCNA


correlation_networks=function(tumours,subset_percentage,num_run)
{
  num_patients=dim(expression_WGCNA_overall[["normal"]][[tumours]])[1]
  num_patients_subset=round(num_patients*subset_percentage)
  
  #new correlation networks template-----> works 
  patient_subset=cbind(sample(1:num_patients,num_patients_subset, replace = FALSE, prob = NULL)
                       ,sample(1:num_patients,num_patients_subset, replace = FALSE, prob = NULL))
  
  #####patient_subset=cbind(1:num_patients_subset,(num_patients_subset+1):(num_patients_subset+num_patients_subset))
  
  
  
  #patient_subset=combn(1:num_patients, num_patients_subset)
  #patient_subset=patient_subset[,round(seq(from =1 , to=dim(patient_subset)[2], by=dim(patient_subset)[2]/num_run))]
  #for (i in 1:num_run)
  for (i in num_run)
  {
    sample_subset=rownames(expression_WGCNA_overall[["normal"]][[tumours]])[patient_subset[,i]]
    temp=paste("sample_subset", i,tumours,subset_percentage, sep="_")
    save(sample_subset, file=paste(temp,".Rdata",sep=""))
    expression_WGCNA=list()
    expression_WGCNA[["normal"]][[tumours]]=expression_WGCNA_overall[["normal"]][[tumours]][patient_subset[,i],]
    expression_WGCNA[["tumour"]][[tumours]]=expression_WGCNA_overall[["tumour"]][[tumours]][patient_subset[,i],]
    
    powers = c(c(1:10), seq(from = 12, to=20, by=2))
    
    sft <- list()
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        sft[[tissue_type]][[tumour]] = pickSoftThreshold(expression_WGCNA[[tissue_type]][[tumour]], powerVector = powers, verbose = 5)
      }
    }
    
    temp=paste("Choosing_soft_thresholds_paired", tumours,i,subset_percentage, sep="_")
    pdf(paste(temp,".pdf",sep=""))
    par(mfrow=c(2,2))
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        local_sft <- sft[[tissue_type]][[tumour]]
        # Scale-free topology fit index as a function of the soft-thresholding power
        plot(local_sft$fitIndices[,1], -sign(local_sft$fitIndices[,3])*local_sft$fitIndices[,2],
             xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n",
             main = paste("Scale independence", tumour, tissue_type, sep="\n"));
        text(local_sft$fitIndices[,1], -sign(local_sft$fitIndices[,3])*local_sft$fitIndices[,2],
             labels=powers,col="red");
        abline(h=0.90,col="red")
        
        # Mean connectivity as a function of the soft-thresholding power
        plot(local_sft$fitIndices[,1], local_sft$fitIndices[,5],
             xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",
             main = paste("Mean connectivity", tumour, tissue_type, sep="\n"))
        text(local_sft$fitIndices[,1], local_sft$fitIndices[,5], labels=powers, col="red")
      }
    }
    dev.off()
    
    soft_threshold <- list()
    soft_threshold[["normal"]][[tumours]] <- sft[["normal"]][[tumours]][["powerEstimate"]]
    soft_threshold[["tumour"]][[tumours]] <- sft[["tumour"]][[tumours]][["powerEstimate"]]
    
    #####################################################-------NEED TO EDIT FILE EACH TIME 
    temp=paste("soft_threshold", tumours,i,subset_percentage, sep="_")
    save(soft_threshold, file=paste(temp,".Rdata",sep=""))
    
    
    ##---- Attempt to save memory space
    remove(sft)
    
    
    #Adjacency matrix and TOM
    adjacency_list <- list()
    dissTOM <- list()
    
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        adjacency_list[[tissue_type]][[tumour]] <- adjacency(expression_WGCNA[[tissue_type]][[tumour]], power = soft_threshold[[tissue_type]][[tumour]])
        TOM = TOMsimilarity(adjacency_list[[tissue_type]][[tumour]])
        dissTOM[[tissue_type]][[tumour]] = 1-TOM
      }
    }
    
    ##---- Attempt to save memory space
    remove(TOM)
    remove(adjacency_list)
    
    #Clustering based on TOM
    minModuleSize = 30;
    
    geneTree <- list()
    dynamicMods <- list()
    dynamicColors <- list()
    
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        geneTree[[tissue_type]][[tumour]] = hclust(as.dist(dissTOM[[tissue_type]][[tumour]]), method = "average")
        dynamicMods[[tissue_type]][[tumour]] = cutreeDynamic(dendro = geneTree[[tissue_type]][[tumour]], 
                                                             distM = dissTOM[[tissue_type]][[tumour]],
                                                             deepSplit = 2, pamRespectsDendro = FALSE,
                                                             minClusterSize = minModuleSize);
        dynamicColors[[tissue_type]][[tumour]] = labels2colors(dynamicMods[[tissue_type]][[tumour]])
        
        print(tumour) 
      }
    }
    
    #######################################################----------NEED TO EDIT FILE LOCATIONS FOR EACH RUN 
    temp=paste("geneTree_paired", tumours,i,subset_percentage, sep="_")
    save(geneTree, file=paste(temp,".Rdata",sep=""))
    
    temp=paste("dynamicColors_paired", tumours,i,subset_percentage, sep="_")
    save(dynamicColors, file=paste(temp,".Rdata",sep=""))
    
    #load("~/Documents/Robustness_networks/WGCNA/Objects/geneTree_paired.Rdata")
    #load("~/Documents/Robustness_networks/WGCNA/Objects/dynamicColors_paired.Rdata")
    
    
    geneTree_with_labels <- list()
    for(tumour in tumours){
      for(tissue_type in c("normal", "tumour")){
        geneTree_with_labels[[tissue_type]][[tumour]] <- geneTree[[tissue_type]][[tumour]]
        geneTree_with_labels[[tissue_type]][[tumour]]$labels <- colnames(expression_WGCNA$normal$COAD)
      }
    }
    
    
    #Asign genes to clusters
    
    cluster_assignments <- list()
    for(tumour in tumours){
      for(tissue_type in c("normal", "tumour")){
        colors <- dynamicColors[[tissue_type]][[tumour]]
        cluster_names <- unique(colors)
        for(cluster in cluster_names){
          indices <- colors == cluster
          cluster_assignments[[tissue_type]][[tumour]][[cluster]] <- colnames(expression_WGCNA[[tissue_type]][[tumour]])[indices]
        }
      }
    }
    ####################################################------Edit gene name
    temp=paste("cluster_assignments", tumours,i,subset_percentage, sep="_")
    save(cluster_assignments, file=paste(temp,".Rdata",sep=""))
  }
}




input="COAD"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="LUAD"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="LUSC"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="BRCA"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="PRAD"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="LIHC"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)
input="STAD"
correlation_networks(input,0.25,1)
#correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
#correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
#correlation_networks(input,0.75,2)

#Place all results in shuffled gene folder 

#determine the similarity results 

tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")

load("Correlation Networks/cluster_assignments.Rdata")
full_set=cluster_assignments
remove(cluster_assignments)

for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      temp=paste("cluster_assignments", t,n,s, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      if (!file.exists(file))
      {
        next 
      }
      
      load(file)
      subset=cluster_assignments
      remove(cluster_assignments)
      
      for (st in sample_type)
      {similarity=matrix(0,nrow=length(full_set[[st]][[t]]),ncol=length(subset[[st]][[t]]))
      rownames(similarity)=names(full_set[[st]][[t]])
      colnames(similarity)=names(subset[[st]][[t]])
      for (i in 1:length(full_set[[st]][[t]]))
      {
        for (j in 1:length(subset[[st]][[t]]))
        {
          similarity[i,j]=length(intersect(full_set[[st]][[t]][[i]],subset[[st]][[t]][[j]]))/length(full_set[[st]][[t]][[i]])
        }
      }
      
      similarity_full_set=matrix(0,nrow=length(full_set[[st]][[t]]),ncol=2)
      rownames(similarity_full_set)=names(full_set[[st]][[t]])
      for (i in 1:length(full_set[[st]][[t]]))
      {
        similarity_full_set[i,1]=max(similarity[i,])
        if (length(colnames(similarity)[similarity[i,]==max(similarity[i,])])==1)
        {
          similarity_full_set[i,2]=colnames(similarity)[similarity[i,]==max(similarity[i,])]
        }
        else
        {
          similarity_full_set[i,2]=length(colnames(similarity)[similarity[i,]==max(similarity[i,])])
        }
      }
      
      similarity_subset=matrix(0,nrow=length(subset[[st]][[t]]),ncol=2)
      rownames(similarity_subset)=names(subset[[st]][[t]])
      for (i in 1:length(subset[[st]][[t]]))
      {
        similarity_subset[i,1]=max(similarity[,i])
        if (length(rownames(similarity)[similarity[,i]==max(similarity[,i])])==1)
        {
          similarity_subset[i,2]=rownames(similarity)[similarity[,i]==max(similarity[,i])]
        }
        else
        {
          similarity_subset[i,2]=length(rownames(similarity)[similarity[,i]==max(similarity[,i])])
        }
      }
      
      temp=paste("similarity", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity, file=file)
      temp=paste("similarity_full_set", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity_full_set, file=file)
      temp=paste("similarity_subset", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity_subset, file=file)
      }
    }
  }
}



#putting all the similarity and cluster assignment results into one list 


tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")

overall_cluster_assignemtns=list()
overall_similarity=list()
overall_similarity_full_set=list()
overall_similarity_subset=list()


for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      temp=paste("cluster_assignments", t,n,s, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      if (!file.exists(file))
      {
        next 
      }
      load(file)
      overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]]=cluster_assignments[["normal"]][[t]]
      overall_cluster_assignemtns[["tumour"]][[paste(t,s,n,sep='_')]]=cluster_assignments[["tumour"]][[t]]
      remove(cluster_assignments)
      for (st in sample_type)
      {temp=paste("similarity", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity[[st]][[paste(t,s,n,sep='_')]]=similarity
      
      temp=paste("similarity_full_set", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]]=similarity_full_set
      
      temp=paste("similarity_subset", t,n,s,st, sep="_")
      file=paste("shuffled correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity_subset[[st]][[paste(t,s,n,sep='_')]]=similarity_subset}
      
    }
  }
}


save(overall_cluster_assignemtns,file="overall_cluster_assignments_shuffled.Rdata")
save(overall_similarity,file="overall_similarity_shuffled.Rdata")
save(overall_similarity_full_set,file="overall_similarity_full_set_shuffled.Rdata")
save(overall_similarity_subset,file="overall_similarity_subset_shuffled.Rdata")





