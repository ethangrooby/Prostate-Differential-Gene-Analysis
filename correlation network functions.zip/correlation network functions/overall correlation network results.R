#overall correlation network results  
#Combining all the similarity and cluster_assignment results into one list

#Setting up variables to run through 
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")
#Initializing variables to store all results 
overall_cluster_assignemtns=list()
overall_similarity=list()
overall_similarity_full_set=list()
overall_similarity_subset=list()
  
  
for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      #reading through files
      temp=paste("cluster_assignments", t,n,s, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      #checking if file exists 
      if (!file.exists(file))
      {
        next 
      }
      #loading and storing file to overall results variable 
      load(file)
      overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]]=cluster_assignments[["normal"]][[t]]
      overall_cluster_assignemtns[["tumour"]][[paste(t,s,n,sep='_')]]=cluster_assignments[["tumour"]][[t]]
      remove(cluster_assignments)
      for (st in sample_type)
      {temp=paste("similarity", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity[[st]][[paste(t,s,n,sep='_')]]=similarity
      
      temp=paste("similarity_full_set", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]]=similarity_full_set
      
      temp=paste("similarity_subset", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      load(file)
      overall_similarity_subset[[st]][[paste(t,s,n,sep='_')]]=similarity_subset}
      
      }
    }
}

#saving all results 
save(overall_cluster_assignemtns,file="overall_cluster_assignments.Rdata")
save(overall_similarity,file="overall_similarity.Rdata")
save(overall_similarity_full_set,file="overall_similarity_full_set.Rdata")
save(overall_similarity_subset,file="overall_similarity_subset.Rdata")

