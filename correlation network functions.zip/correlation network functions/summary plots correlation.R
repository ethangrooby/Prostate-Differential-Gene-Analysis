#First part of code determines the percentage of miss runs in the data as defined by the cluster assignments only producing one module 
#Second part is to produce some summary graphs of the distribution of best similarity results for each module

#determing the percentage of miss runs 
load("overall_cluster_assignments.Rdata")
run_name=names(overall_cluster_assignemtns[["normal"]])
sample_type=c("normal","tumour")
miss_run=0
for (i in run_name)
{
  for (st in sample_type)
  {
    if (length(overall_cluster_assignemtns[[st]][[i]])==1)
    {
      miss_run=miss_run+1
    }
  }
}
percentage_miss_run=miss_run/(length(run_name)*2)

#percentage_miss_run=0.1071429

#producing summary graphs 

load("overall_similarity.Rdata")
load("overall_similarity_full_set.Rdata")
load("overall_similarity_subset.Rdata")
load("UC_Similarity_analysis.Rdata")


tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")


for (t in tumours)
{
  tumour_summary=list()
  for (s in subset_percentage)
  {
    temp=c()
    for (n in num_run)
      #all the simulated runs for the same tumour and subset percentage are grouped together
    {
      #ignoring miss runs 
      if(length(overall_cluster_assignemtns[["tumour"]][[paste(t,s,n,sep='_')]])!=1)
      {
        temp=c(temp,as.numeric(overall_similarity_full_set[["tumour"]][[paste(t,s,n,sep='_')]][,1]))
      }
    }
    tumour_summary[[paste(s)]]=temp
  }
  #producing a graph for each tumour type with the x axis being the subset percentage determined and the y axis being the percentage similarity. 
  #distribution for each subset percentage is displayed as a boxplot 
  boxplot(tumour_summary,main=t,xlab='% subset',ylab='% similarity')
}

#producing the boxplot results for all the normal data combined regardless of what tumour type the normal data came from
tumour_summary=list()
for (s in subset_percentage)
{
  temp=c()
  for (t in tumours)
  {
    for (n in num_run)
    {
      if(length(overall_cluster_assignemtns[["normal"]][[paste(t,s,n,sep='_')]])!=1)
      {
        temp=c(temp,as.numeric(overall_similarity_full_set[["normal"]][[paste(t,s,n,sep='_')]][,1]))
      }
    }
    
  }
  tumour_summary[[paste(s)]]=temp
}
boxplot(tumour_summary,main="Normal",xlab='% subset',ylab='% similarity')


#prodicing summary boxplot result for all the shuffled data 

load("overall_cluster_assignments_shuffled.Rdata")
load("overall_similarity_full_set_shuffled.Rdata")
tumour_summary=list()
for (s in subset_percentage)
{
  temp=c()
  for (t in tumours)
  {
    for (n in num_run)
    {
      for (st in sample_type)
      {
        if(length(overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]])!=1)
        {
          temp=c(temp,as.numeric(overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]][,1]))
        }
      }
      
    }
    
  }
  tumour_summary[[paste(s)]]=temp
}
boxplot(tumour_summary,main="Shuffled",xlab='% subset',ylab='% similarity')

