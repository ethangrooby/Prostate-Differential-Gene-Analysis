#This script codes for the function correlation_networks. Which produces the cluster assignments for a 
#randomly generated subset of individual data for a particular tumour for num_run many times 
#Inputs
#tumours which can be any or all of the following tumours_options <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
#subset percentage= percentage of individuals you want to randomly select 
#num_run= number of simulation runs 



memory.limit(15000)
library(WGCNA)
load("Correlation Networks/expression_WGCNA_paired.Rdata")
expression_WGCNA_overall=expression_WGCNA
remove(expression_WGCNA)



correlation_networks=function(tumours,subset_percentage,num_run)
{
  #randomly generating subsets 
  num_patients=dim(expression_WGCNA_overall[["normal"]][[tumours]])[1]
  num_patients_subset=round(num_patients*subset_percentage)
  
  #could change to make num_run amount of subsets and run through them, at the moment produces only 2 random subsets therefore max of value of num_run=2
  patient_subset=cbind(sample(1:num_patients,num_patients_subset, replace = FALSE, prob = NULL)
                       ,sample(1:num_patients,num_patients_subset, replace = FALSE, prob = NULL))

  #for (i in 1:num_run) potential edit to run multiple times 
  for (i in num_run)
  {
    #code from Anna to determine soft_threshold and cluster assignements
    sample_subset=rownames(expression_WGCNA_overall[["normal"]][[tumours]])[patient_subset[,i]]
    temp=paste("sample_subset", i,tumours,subset_percentage, sep="_")
    save(sample_subset, file=paste(temp,".Rdata",sep=""))
    expression_WGCNA=list()
    expression_WGCNA[["normal"]][[tumours]]=expression_WGCNA_overall[["normal"]][[tumours]][patient_subset[,i],]
    expression_WGCNA[["tumour"]][[tumours]]=expression_WGCNA_overall[["tumour"]][[tumours]][patient_subset[,i],]
    
    powers = c(c(1:10), seq(from = 12, to=20, by=2))
    
    sft <- list()
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        sft[[tissue_type]][[tumour]] = pickSoftThreshold(expression_WGCNA[[tissue_type]][[tumour]], powerVector = powers, verbose = 5)
      }
    }
    
    temp=paste("Choosing_soft_thresholds_paired", tumours,i,subset_percentage, sep="_")
    pdf(paste(temp,".pdf",sep=""))
    par(mfrow=c(2,2))
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        local_sft <- sft[[tissue_type]][[tumour]]
        # Scale-free topology fit index as a function of the soft-thresholding power
        plot(local_sft$fitIndices[,1], -sign(local_sft$fitIndices[,3])*local_sft$fitIndices[,2],
             xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n",
             main = paste("Scale independence", tumour, tissue_type, sep="\n"));
        text(local_sft$fitIndices[,1], -sign(local_sft$fitIndices[,3])*local_sft$fitIndices[,2],
             labels=powers,col="red");
        abline(h=0.90,col="red")
        
        # Mean connectivity as a function of the soft-thresholding power
        plot(local_sft$fitIndices[,1], local_sft$fitIndices[,5],
             xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",
             main = paste("Mean connectivity", tumour, tissue_type, sep="\n"))
        text(local_sft$fitIndices[,1], local_sft$fitIndices[,5], labels=powers, col="red")
      }
    }
    dev.off()
    
    soft_threshold <- list()
    soft_threshold[["normal"]][[tumours]] <- sft[["normal"]][[tumours]][["powerEstimate"]]
    soft_threshold[["tumour"]][[tumours]] <- sft[["tumour"]][[tumours]][["powerEstimate"]]
    
    #####################################################-------NEED TO EDIT FILE EACH TIME 
    temp=paste("soft_threshold", tumours,i,subset_percentage, sep="_")
    save(soft_threshold, file=paste(temp,".Rdata",sep=""))
    
    
    ##---- Attempt to save memory space
    remove(sft)
    
    
    #Adjacency matrix and TOM
    adjacency_list <- list()
    dissTOM <- list()
    
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        adjacency_list[[tissue_type]][[tumour]] <- adjacency(expression_WGCNA[[tissue_type]][[tumour]], power = soft_threshold[[tissue_type]][[tumour]])
        TOM = TOMsimilarity(adjacency_list[[tissue_type]][[tumour]])
        dissTOM[[tissue_type]][[tumour]] = 1-TOM
      }
    }
    
    ##---- Attempt to save memory space
    remove(TOM)
    remove(adjacency_list)
    
    #Clustering based on TOM
    minModuleSize = 30;
    
    geneTree <- list()
    dynamicMods <- list()
    dynamicColors <- list()
    
    for(tissue_type in c("normal", "tumour")){
      for(tumour in tumours){
        geneTree[[tissue_type]][[tumour]] = hclust(as.dist(dissTOM[[tissue_type]][[tumour]]), method = "average")
        dynamicMods[[tissue_type]][[tumour]] = cutreeDynamic(dendro = geneTree[[tissue_type]][[tumour]], 
                                                             distM = dissTOM[[tissue_type]][[tumour]],
                                                             deepSplit = 2, pamRespectsDendro = FALSE,
                                                             minClusterSize = minModuleSize);
        dynamicColors[[tissue_type]][[tumour]] = labels2colors(dynamicMods[[tissue_type]][[tumour]])
        
        print(tumour) 
      }
    }
    
    #######################################################----------NEED TO EDIT FILE LOCATIONS FOR EACH RUN 
    temp=paste("geneTree_paired", tumours,i,subset_percentage, sep="_")
    save(geneTree, file=paste(temp,".Rdata",sep=""))
    
    temp=paste("dynamicColors_paired", tumours,i,subset_percentage, sep="_")
    save(dynamicColors, file=paste(temp,".Rdata",sep=""))
    
    #load("~/Documents/Robustness_networks/WGCNA/Objects/geneTree_paired.Rdata")
    #load("~/Documents/Robustness_networks/WGCNA/Objects/dynamicColors_paired.Rdata")
    
    
    geneTree_with_labels <- list()
    for(tumour in tumours){
      for(tissue_type in c("normal", "tumour")){
        geneTree_with_labels[[tissue_type]][[tumour]] <- geneTree[[tissue_type]][[tumour]]
        geneTree_with_labels[[tissue_type]][[tumour]]$labels <- colnames(expression_WGCNA$normal$COAD)
      }
    }
    
    
    #Asign genes to clusters
    
    cluster_assignments <- list()
    for(tumour in tumours){
      for(tissue_type in c("normal", "tumour")){
        colors <- dynamicColors[[tissue_type]][[tumour]]
        cluster_names <- unique(colors)
        for(cluster in cluster_names){
          indices <- colors == cluster
          cluster_assignments[[tissue_type]][[tumour]][[cluster]] <- colnames(expression_WGCNA[[tissue_type]][[tumour]])[indices]
        }
      }
    }
    ####################################################------Edit gene name
    temp=paste("cluster_assignments", tumours,i,subset_percentage, sep="_")
    save(cluster_assignments, file=paste(temp,".Rdata",sep=""))
  }
}


###-Running through function for disired subsets 
input="COAD"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="LUAD"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="LUSC"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="BRCA"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="PRAD"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="LIHC"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)
input="STAD"
correlation_networks(input,0.25,1)
correlation_networks(input,0.25,2)
correlation_networks(input,0.5,1)
correlation_networks(input,0.5,2)
correlation_networks(input,0.75,1)
correlation_networks(input,0.75,2)








