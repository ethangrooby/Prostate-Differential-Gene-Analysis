#Comparing subsets with actual original cluster assignments using all individual data 

#similarity defined as number of genes in common with original cluster assignment and generated subset cluster assignment modules divided by 
#the number of genes in the original cluster assignment module 

#Setting up variables to run through
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")

#loading the original cluster assignemtns 
load("Correlation Networks/cluster_assignments.Rdata")
full_set=cluster_assignments
remove(cluster_assignments)

for (t in tumours)
{
  for (s in subset_percentage)
  {
    for (n in num_run)
    {
      #creating file name 
      temp=paste("cluster_assignments", t,n,s, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      #checking if file exists
      if (!file.exists(file))
      {
        next 
      }
      #loading file which contains the cluster assignments for the subset
      load(file)
      subset=cluster_assignments
      remove(cluster_assignments)
      #comparing original set with subset similarity. Similarity score defined as no. genes in both module sets 
      #divided by total genes in the original module set
      for (st in sample_type)
      {similarity=matrix(0,nrow=length(full_set[[st]][[t]]),ncol=length(subset[[st]][[t]]))
      rownames(similarity)=names(full_set[[st]][[t]])
      colnames(similarity)=names(subset[[st]][[t]])
      for (i in 1:length(full_set[[st]][[t]]))
      {
        for (j in 1:length(subset[[st]][[t]]))
        {
          similarity[i,j]=length(intersect(full_set[[st]][[t]][[i]],subset[[st]][[t]][[j]]))/length(full_set[[st]][[t]][[i]])
        }
      }
      #similarity_full_set= contains the maximum similarity score for each module in the 
      #original set and the corresponding module in the subset that it occurs 
      similarity_full_set=matrix(0,nrow=length(full_set[[st]][[t]]),ncol=2)
      rownames(similarity_full_set)=names(full_set[[st]][[t]])
      for (i in 1:length(full_set[[st]][[t]]))
      {
        similarity_full_set[i,1]=max(similarity[i,])
        #if there are two best matches, instead of displaying a module name, the number of best match modules is displayed
        if (length(colnames(similarity)[similarity[i,]==max(similarity[i,])])==1)
        {
          similarity_full_set[i,2]=colnames(similarity)[similarity[i,]==max(similarity[i,])]
        }
        else
        {
          similarity_full_set[i,2]=length(colnames(similarity)[similarity[i,]==max(similarity[i,])])
        }
      }
      #similarity_subset=Overall_similarity_subset.Rdata: contains the maximum similarity 
      #score for each module in the subset and the corresponding module in the subset that it occurs 
      similarity_subset=matrix(0,nrow=length(subset[[st]][[t]]),ncol=2)
      rownames(similarity_subset)=names(subset[[st]][[t]])
      for (i in 1:length(subset[[st]][[t]]))
      {
        similarity_subset[i,1]=max(similarity[,i])
        #if there are two best matches, instead of displaying a module name, the number of best match modules is displayed
        if (length(rownames(similarity)[similarity[,i]==max(similarity[,i])])==1)
        {
          similarity_subset[i,2]=rownames(similarity)[similarity[,i]==max(similarity[,i])]
        }
        else
        {
          similarity_subset[i,2]=length(rownames(similarity)[similarity[,i]==max(similarity[,i])])
        }
      }
      #saving all the similarity results 
      temp=paste("similarity", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity, file=file)
      temp=paste("similarity_full_set", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity_full_set, file=file)
      temp=paste("similarity_subset", t,n,s,st, sep="_")
      file=paste("correlation network results/",t,'/',temp,".Rdata",sep="")
      save(similarity_subset, file=file)
      }
    }
  }
}



