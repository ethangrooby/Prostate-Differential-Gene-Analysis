#module ages
##### Calculating TAI age for each module in the original set 

#loading required data 
Phylostrata=read.csv(file="Phylostrata.csv")
load("Correlation Networks/cluster_assignments.Rdata")
load("Correlation Networks/expression_WGCNA_paired.Rdata")
#Setting up variables to run through
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
sample_type=c("normal","tumour")
TAI=list()
for (t in tumours)
{
  for (st in sample_type)
  {
    temp=matrix(0,nrow=length(cluster_assignments[[st]][[t]]),ncol=1)
    rownames(temp)=names(cluster_assignments[[st]][[t]])
    
    for (i in 1:length(cluster_assignments[[st]][[t]]))
    {
      expression=0
      p_expression=0
      #running through all the genes in a module
      for (j in 1:length(cluster_assignments[[st]][[t]][[i]]))
      {
        #checking if gene is listed in the phylostrata list
        if (sum(Phylostrata[,1]==cluster_assignments[[st]][[t]][[i]][j])==1)
        {
          #calculating the cumulative expression and cumulative expression times phylostrata
          expression=expression+mean(expression_WGCNA[[st]][[t]][,colnames(expression_WGCNA[[st]][[t]])==cluster_assignments[[st]][[t]][[i]][j]])
          p_expression=p_expression+mean(expression_WGCNA[[st]][[t]][,colnames(expression_WGCNA[[st]][[t]])==
                    cluster_assignments[[st]][[t]][[i]][j]])*Phylostrata[Phylostrata[,1]==cluster_assignments[[st]][[t]][[i]][j],3]
        }
      
      }
      color=names(cluster_assignments[[st]][[t]])[i]
      #calculating TAI for this module 
      temp[i,1]=p_expression/expression
    }
    #storing all TAI 
    TAI[[st]][[t]]=temp
  }
}

save(TAI,file='TAI_gene_networks.Rdata')


###### Calculate the percentage of unicellular genes in the original
#modules and in the most similar module (add it as a column to your data frames). 
#Unicellular genes are those belonging to phylostratum 1, 2 and 3 in the table of gene ages.
#Storing this in a UC_Similarity_analysis list which stores the results in this format:
# rowname=module of original set   col1=%UC in original set  col2=%similarity in most similar module
#col3=most similar module in subset  col4=%UC in most similar module

load("Correlation Networks/cluster_assignments.Rdata")
load("overall_similarity_full_set.Rdata")
load("overall_cluster_assignments.Rdata")

Phylostrata=read.csv(file="Phylostrata.csv")
#Setting up variables to run through
tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
#remove 0.75 to see what happens as i am missing the 0.25 and 0.5 data 
num_run=c(1,2)
sample_type=c("normal","tumour")

UC_Similarity_analysis=list()

for (st in sample_type)
{
  for (t in tumours)
  {
    #calculating %UC for original module subset 
    UC=matrix(0,nrow=length(cluster_assignments[[st]][[t]]),ncol=1)
    for (i in 1:length(cluster_assignments[[st]][[t]]))
    {
      UC_count=0
      for (j in 1:length(cluster_assignments[[st]][[t]][[i]]))
      {
        if (sum(Phylostrata[,1]==cluster_assignments[[st]][[t]][[i]][j])==1)
        {
          if (Phylostrata[Phylostrata[,1]==cluster_assignments[[st]][[t]][[i]][j],3]<4)
          {
            UC_count=UC_count+1
          }
        }
        
      }
      UC[i,1]=UC_count/length(cluster_assignments[[st]][[t]][[i]])
    }
    for (n in num_run)
    {
      for (s in subset_percentage)
      {
        #obtaining %similarity and most similar module from overall_similarity_full_set
        temp=matrix(0,nrow=dim(overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]])[1],ncol=4)
        temp[,c(2,3)]=overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]]
        rownames(temp)=rownames(overall_similarity_full_set[[st]][[paste(t,s,n,sep='_')]])
        temp[,1]=UC
        #calculating %UC in most simliar module from subset 
        UC_2=matrix(0,nrow=length(cluster_assignments[[st]][[t]]),ncol=1)
          
        for (i in 1:length(cluster_assignments[[st]][[t]]))
        {
          color=temp[i,3]
          if (sum(names(overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]])==color)==0)
          {
            #as sometimes there is multiple modules that are a best match with the original module, UC component is not calculated 
            #and instead is stored as -1
            UC_2[i,1]=-1
            next
          }
          UC_count=0
          for (j in 1:length(overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]][[color]]))
          {
            if (sum(Phylostrata[,1]==overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]][[color]][j])==1)
            {
              if (Phylostrata[Phylostrata[,1]==overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]][[color]][j],3]<4)
              {
                UC_count=UC_count+1
              }
            }
              
          }
          UC_2[i,1]=UC_count/length(overall_cluster_assignemtns[[st]][[paste(t,s,n,sep='_')]][[color]])
        }
        temp[,4]=UC_2
        colnames(temp)=c('%UC original','%similarity','most similar module','%UC in most similar module')
        #storing all results in UC_Similarity_analysis
        UC_Similarity_analysis[[st]][[paste(t,s,n,sep='_')]]=temp
      }
      
    }
  }
}



save(UC_Similarity_analysis,file='UC_Similarity_analysis.Rdata')





