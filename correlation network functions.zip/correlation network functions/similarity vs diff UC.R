#This script produces graphs for the difference in unicellular components in the original module and the best similarity subset module (y axis)
#vs the percentage similarity between them modules (x axis)

#loading the pre-setting data to run through 
load("UC_Similarity_analysis.Rdata")
load("overall_cluster_assignments.Rdata")

tumours <- c("LUAD", "LUSC", "BRCA", "PRAD", "LIHC", "COAD", "STAD")
subset_percentage=c(0.25,0.5,0.75)
num_run=c(1,2)
sample_type=c("normal","tumour")

for (st in sample_type)
{
  par(mfrow=c(4,2)) 
  for (t in tumours)
  {
    similarity=c()
    diff_UC=c()
    for (s in subset_percentage)
    {
      for (n in num_run)
      {
        #excluding miss runs 
        if(length(overall_cluster_assignemtns[["tumour"]][[paste(t,s,n,sep='_')]])!=1)
        {
          #a and b are the %uc compononent in the original and subset module respectively. c is the %similarity
          a=as.numeric(UC_Similarity_analysis[[st]][[paste(t,s,n,sep='_')]][,1])
          b=as.numeric(UC_Similarity_analysis[[st]][[paste(t,s,n,sep='_')]][,4])
          c=as.numeric(UC_Similarity_analysis[[st]][[paste(t,s,n,sep='_')]][,2])
          #removing UC values of -1 as this represents multiple modules being the best match to one original module
          c=c[b!=-1]
          similarity=c(similarity,c)
          a=a[b!=-1]
          b=b[b!=-1]
          #taking the magnitude of the difference in UC values 
          diff_UC=c(diff_UC,abs(a-b))
        }
        

        
      }
    }
    #removing similarity values of 1 as this indicates a that there is one big subset module which contains multiple original values, thus producing
    # similarity values of 1 and a irrelvant %UC that is not useful in this analysis 
    similarity_removed=similarity[similarity!=1]
    diff_UC_removed=diff_UC[similarity!=1]
    temp=paste(st,t,sep='_')
    #determining the correlation between differnce in unicellular composition and similarity
    temp=paste(temp,' cor=',round(cor(similarity_removed,diff_UC_removed),2))
    #determing the linear model of the graph 
    test=lm(diff_UC_removed~similarity_removed)
    temp=paste(temp, paste("y=",round(test[["coefficients"]][1],2),"+",round(test[["coefficients"]][2],2),"x",sep=""),sep=" ")
    plot(similarity_removed,diff_UC_removed,main=temp)
    lines(c(0,1),c(test[["coefficients"]][1],test[["coefficients"]][1]+test[["coefficients"]][2]),col="green")
  }
}






