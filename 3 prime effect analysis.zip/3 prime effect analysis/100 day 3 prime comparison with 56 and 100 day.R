#This script compares 3 prime sequencing with normal sequencing
#To determine if the 100 day 3 prime sequenced data is more related to 100 day normal sequenced data or the 56 3 primed sequenced data


temp=read.csv(file="100 day results/mouse2human_rlogwtmutant_5prime.csv")
rlog_wtmutant=as.matrix(temp[,2:3])
rownames(rlog_wtmutant)=temp[,1]
library(GSVA)
library(GSEABase)
#determing the gene enrichment scores for GOslim and cancer hallmark sets 
GOslim_set<-getGmt('gene sets/GOslim_Anna.gmt')
gsvaEnrichmentScore_GOslim_set_100_3prime<-gsva(rlog_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
msigDB50<-getGmt("gene sets/h.all.v6.1.symbols.gmt")
gsvaEnrichmentScore_100_3prime<-gsva(rlog_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)

temp=read.csv(file="56 day results/mouse2human_rlogwtmutant.csv")
rlog_wtmutant=as.matrix(temp[,2:9])
rownames(rlog_wtmutant)=temp[,1]
gsvaEnrichmentScore_GOslim_set_56_day<-gsva(rlog_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_56_day<-gsva(rlog_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)


temp=read.csv(file="100 day results/mouse2human_normalized_wtmutant.csv")
normalized_wtmutant=as.matrix(temp[,2:11])
rownames(normalized_wtmutant)=temp[,1]
gsvaEnrichmentScore_GOslim_set_100_day<-gsva(normalized_wtmutant,GOslim_set,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)
gsvaEnrichmentScore_100_day<-gsva(normalized_wtmutant,msigDB50,method="ssgsea" ,rnaseq=TRUE,mx.diff=TRUE,abs.ranking=TRUE)

#determing the average gene enrichment scores for wildtype and mutant 
gsvaEnrichmentScore_56_day_avg=matrix(0,nrow=50,ncol=2)
rownames(gsvaEnrichmentScore_56_day_avg)=rownames(gsvaEnrichmentScore_56_day)
gsvaEnrichmentScore_100_day_avg=matrix(0,nrow=50,ncol=2)
rownames(gsvaEnrichmentScore_100_day_avg)=rownames(gsvaEnrichmentScore_56_day)
for (i in 1:50)
{

  gsvaEnrichmentScore_56_day_avg[i,1]=mean(gsvaEnrichmentScore_56_day[i,1:4])
  gsvaEnrichmentScore_56_day_avg[i,2]=mean(gsvaEnrichmentScore_56_day[i,5:8])
  gsvaEnrichmentScore_100_day_avg[i,1]=mean(gsvaEnrichmentScore_100_day[i,1:5])
  gsvaEnrichmentScore_100_day_avg[i,2]=mean(gsvaEnrichmentScore_100_day[i,6:10])
}

gsvaEnrichmentScore_GOslim_set_56_day_avg=matrix(0,nrow=67,ncol=2)
rownames(gsvaEnrichmentScore_GOslim_set_56_day_avg)=rownames(gsvaEnrichmentScore_GOslim_set_56_day)
gsvaEnrichmentScore_GOslim_set_100_day_avg=matrix(0,nrow=67,ncol=2)
rownames(gsvaEnrichmentScore_GOslim_set_100_day_avg)=rownames(gsvaEnrichmentScore_GOslim_set_56_day)
for (i in 1:67)
{
  gsvaEnrichmentScore_GOslim_set_56_day_avg[i,1]=mean(gsvaEnrichmentScore_GOslim_set_56_day[i,1:4])
  gsvaEnrichmentScore_GOslim_set_56_day_avg[i,2]=mean(gsvaEnrichmentScore_GOslim_set_56_day[i,5:8])
  gsvaEnrichmentScore_GOslim_set_100_day_avg[i,1]=mean(gsvaEnrichmentScore_GOslim_set_100_day[i,1:5])
  gsvaEnrichmentScore_GOslim_set_100_day_avg[i,2]=mean(gsvaEnrichmentScore_GOslim_set_100_day[i,6:10])
}

#Ranking of processes
GOslim_rank=matrix(0,nrow=67,ncol=3)
GOslim_rank_all=matrix(0,nrow=67,ncol=6)
for (i in 1:67)
{
  a=match(i,order(gsvaEnrichmentScore_GOslim_set_56_day_avg[,1]))
  b=match(i,order(gsvaEnrichmentScore_GOslim_set_56_day_avg[,2]))
  c=match(i,order(gsvaEnrichmentScore_GOslim_set_100_day_avg[,1]))
  d=match(i,order(gsvaEnrichmentScore_GOslim_set_100_day_avg[,2]))
  e=match(i,order(gsvaEnrichmentScore_GOslim_set_100_3prime[,1]))
  f=match(i,order(gsvaEnrichmentScore_GOslim_set_100_3prime[,2]))
  GOslim_rank[i,]=c(a-b,c-d,e-f)
  GOslim_rank_all[i,]=c(a,b,c,d,e,f)
}

cancer_rank=matrix(0,nrow=50,ncol=3)
cancer_rank_all=matrix(0,nrow=50,ncol=6)
for (i in 1:50)
{
  a=match(i,order(gsvaEnrichmentScore_56_day_avg[,1]))
  b=match(i,order(gsvaEnrichmentScore_56_day_avg[,2]))
  c=match(i,order(gsvaEnrichmentScore_100_day_avg[,1]))
  d=match(i,order(gsvaEnrichmentScore_100_day_avg[,2]))
  e=match(i,order(gsvaEnrichmentScore_100_3prime[,1]))
  f=match(i,order(gsvaEnrichmentScore_100_3prime[,2]))
  cancer_rank[i,]=c(a-b,c-d,e-f)
  cancer_rank_all[i,]=c(a,b,c,d,e,f)
}






library(pheatmap)


#producing heatmaps of the ranks to see how clustering between 100 day, 56 3 prime and 100 3 prime occur 
rownames(GOslim_rank_all)=rownames(gsvaEnrichmentScore_GOslim_set_56_day)
colnames(GOslim_rank_all)=c('56m','56wt','100m','100wt','100 3m','100 3wt')
rownames(cancer_rank_all)=rownames(gsvaEnrichmentScore_100_3prime)
colnames(cancer_rank_all)=c('56m','56wt','100m','100wt','100 3m','100 3wt')
pheatmap(GOslim_rank_all,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)
pheatmap(cancer_rank_all,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)

pheatmap(GOslim_rank_all[,c(1,3,5)],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)
pheatmap(GOslim_rank_all[,c(2,4,6)],show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)


#correlation analysis of the ranks of the gene sets to determine which is more closely related
cor(cancer_rank[,1],cancer_rank[,2])
cor(cancer_rank[,1],cancer_rank[,3])
cor(cancer_rank[,2],cancer_rank[,3])

cor(GOslim_rank[,1],GOslim_rank[,2])
cor(GOslim_rank[,1],GOslim_rank[,3])
cor(GOslim_rank[,2],GOslim_rank[,3])



#redundant code below (previous attempts of comparing the sets of data)

temp=cbind(gsvaEnrichmentScore_56_day,gsvaEnrichmentScore_100_day,gsvaEnrichmentScore_100_3prime)
colnames(temp)=c('56 m1','56 m2', '56 m3','56 m4','56 wt1','56 wt2','56 wt3','56 wt4',
                 '100 m1','100 m2', '100 m3','100 m4','100 m5','100 wt1','100 wt2','100 wt3','100 wt4','100 wt5',
                 '100 3 m', '100 3 wt')
pheatmap(temp,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)


temp=cbind(gsvaEnrichmentScore_GOslim_set_56_day,gsvaEnrichmentScore_GOslim_set_100_day,gsvaEnrichmentScore_GOslim_set_100_3prime)
colnames(temp)=c('56 m1','56 m2', '56 m3','56 m4','56 wt1','56 wt2','56 wt3','56 wt4',
                 '100 m1','100 m2', '100 m3','100 m4','100 m5','100 wt1','100 wt2','100 wt3','100 wt4','100 wt5',
                 '100 3 m', '100 3 wt')
pheatmap(temp,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)

rownames(cancer_rank)=rownames(gsvaEnrichmentScore_100_3prime)
colnames(cancer_rank)=c('56','100','100 3')
pheatmap(cancer_rank,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)
rownames(GOslim_rank)=rownames(gsvaEnrichmentScore_GOslim_set_56_day)
colnames(GOslim_rank)=c('56','100','100 3')
pheatmap(GOslim_rank,show_rownames=TRUE,cluster_rows=FALSE,fontsize_row=7.5)


plot(cancer_rank_all[,1],cancer_rank_all[,3])
plot(cancer_rank_all[,1],cancer_rank_all[,5])
plot(cancer_rank_all[,3],cancer_rank_all[,5])
plot(cancer_rank_all[,2],cancer_rank_all[,4])
plot(cancer_rank_all[,2],cancer_rank_all[,6])
plot(cancer_rank_all[,4],cancer_rank_all[,6])

plot(GOslim_rank_all[,1],GOslim_rank_all[,3])
plot(GOslim_rank_all[,1],GOslim_rank_all[,5])
plot(GOslim_rank_all[,3],GOslim_rank_all[,5])
plot(GOslim_rank_all[,2],GOslim_rank_all[,4])
plot(GOslim_rank_all[,2],GOslim_rank_all[,6])
plot(GOslim_rank_all[,4],GOslim_rank_all[,6])
correlation_cancer=matrix(0,nrow=6,ncol=1)
correlation_cancer[1,1]=cor(cancer_rank_all[,1],cancer_rank_all[,3])
correlation_cancer[2,1]=cor(cancer_rank_all[,1],cancer_rank_all[,5])
correlation_cancer[3,1]=cor(cancer_rank_all[,3],cancer_rank_all[,5])
correlation_cancer[4,1]=cor(cancer_rank_all[,2],cancer_rank_all[,4])
correlation_cancer[5,1]=cor(cancer_rank_all[,2],cancer_rank_all[,6])
correlation_cancer[6,1]=cor(cancer_rank_all[,4],cancer_rank_all[,6])
correlation_GOslim=matrix(0,nrow=6,ncol=1)
correlation_GOslim[1,1]=cor(GOslim_rank_all[,1],GOslim_rank_all[,3])
correlation_GOslim[2,1]=cor(GOslim_rank_all[,1],GOslim_rank_all[,5])
correlation_GOslim[3,1]=cor(GOslim_rank_all[,3],GOslim_rank_all[,5])
correlation_GOslim[4,1]=cor(GOslim_rank_all[,2],GOslim_rank_all[,4])
correlation_GOslim[5,1]=cor(GOslim_rank_all[,2],GOslim_rank_all[,6])
correlation_GOslim[6,1]=cor(GOslim_rank_all[,4],GOslim_rank_all[,6])